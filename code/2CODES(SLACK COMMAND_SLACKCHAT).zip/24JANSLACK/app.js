const express = require('express');
const bodyParser = require('body-parser');
const crypto = require('crypto');
require('dotenv').config();

const app = express();

// Middleware to parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

// Slack request verification middleware
app.use((req, res, next) => {
  try {
    const slackSignature = req.headers['x-slack-signature'];
    const timestamp = req.headers['x-slack-request-timestamp'];

    // Prevent replay attacks (allow requests within 5 minutes)
    const FIVE_MINUTES = 60 * 5;
    if (Math.abs(Date.now() / 1000 - timestamp) > FIVE_MINUTES) {
      return res.status(400).send('Request too old.');
    }

    // Verify Slack signature
    const sigBaseString = `v0:${timestamp}:${Object.entries(req.body || {})
      .map(([key, value]) => `${key}=${value}`)
      .join('&')}`;
    const hmac = crypto
      .createHmac('sha256', process.env.SLACK_SIGNING_SECRET)
      .update(sigBaseString, 'utf8')
      .digest('hex');
    const calculatedSignature = `v0=${hmac}`;

    if (slackSignature && crypto.timingSafeEqual(Buffer.from(slackSignature), Buffer.from(calculatedSignature))) {
      next();
    } else {
      res.status(400).send('Verification failed.');
    }
  } catch (error) {
    console.error('Error verifying request:', error);
    res.status(400).send('Verification error.');
  }
});

// Route to handle Slash Commands
app.post('/slack/commands', (req, res) => {
  const { command, text } = req.body;

  if (command === '/hello') {
    res.status(200).send(`Hello! 👋 You said: "${text}"`);
  } else if (command === '/weather') {
    const location = text || 'your location';
    res.status(200).send(`🌤️ Weather for ${location}:
    - Temperature: 72°F
    - Condition: Sunny
    - Humidity: 45%`);
  } else {
    res.status(200).send('Unknown command!');
  }
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`⚡️ Slack bot is running on port ${PORT}`);
});
