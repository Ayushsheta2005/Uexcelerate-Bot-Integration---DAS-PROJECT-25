const goals = [];

module.exports = {
  createGoal: async (body, say) => {
    await say({
      text: 'Create a New Goal',
      blocks: [
        {
          type: 'section',
          text: { 
            type: 'mrkdwn', 
            text: '*Create a New Goal* 🎯\nDescribe your goal briefly:' 
          }
        }
      ]
    });
  },

  listGoals: () => ({
    text: 'Your Goals',
    blocks: [
      {
        type: 'section',
        text: { type: 'mrkdwn', text: '*Your Goals* 📋' }
      },
      ...(goals.length > 0 
        ? goals.map(goal => ({
            type: 'section',
            text: { type: 'mrkdwn', text: `• ${goal}` }
          }))
        : [{
            type: 'section',
            text: { type: 'mrkdwn', text: 'No goals created yet. Start by setting your first goal!' }
          }]
      )
    ]
  })
};