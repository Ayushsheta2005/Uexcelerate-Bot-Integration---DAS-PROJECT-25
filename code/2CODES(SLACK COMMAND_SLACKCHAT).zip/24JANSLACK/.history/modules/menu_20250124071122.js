module.exports = {
  generateMainMenu: () => ({
    text: 'Coaching Companion Main Menu',
    blocks: [
      {
        type: 'section',
        text: { 
          type: 'mrkdwn', 
          text: '*Welcome to Coaching Companion* 🚀\nChoose an option:' 
        }
      },
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: { type: 'plain_text', text: 'Coaches 👥' },
            action_id: 'coaches_menu',
            value: 'coaches_menu'
          },
          {
            type: 'button',
            text: { type: 'plain_text', text: 'Goals 🎯' },
            action_id: 'goals_menu',
            value: 'goals_menu'
          },
          {
            type: 'button',
            text: { type: 'plain_text', text: 'Sessions 📅' },
            action_id: 'sessions_menu',
            value: 'sessions_menu'
          }
        ]
      }
    ]
  })
};