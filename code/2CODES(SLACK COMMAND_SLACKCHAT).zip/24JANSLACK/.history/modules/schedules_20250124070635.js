const { searchCoaches } = require('./
const sessions = [];

module.exports = {
  scheduleSession: async (body, say) => {
    await say({
      blocks: [
        {
          type: 'section',
          text: { 
            type: 'mrkdwn', 
            text: '*Schedule Coaching Session* 📅\n\nSelect a coach to begin:' 
          }
        },
        ...(searchCoaches().blocks.slice(1))
      ]
    });
  },

  listSessions: () => ({
    blocks: [
      {
        type: 'section',
        text: { type: 'mrkdwn', text: '*Scheduled Sessions* 🕒' }
      },
      ...(sessions.length > 0 
        ? sessions.map((session, index) => ({
            type: 'section',
            text: { 
              type: 'mrkdwn', 
              text: `*Session ${index + 1}:*\n• *Coach:* ${session.coach}\n• *Date:* ${session.date}\n• *Time:* ${session.time}` 
            },
            accessory: {
              type: 'button',
              text: { type: 'plain_text', text: 'Cancel' },
              style: 'danger',
              value: `cancel_session_${index}`,
              action_id: 'cancel_session'
            }
          }))
        : [{
            type: 'section',
            text: { type: 'mrkdwn', text: 'No sessions scheduled. Book your first coaching session!' }
          }]
      )
    ]
  }),

  cancelSession: async (body, say) => {
    await say({
      blocks: [
        {
          type: 'section',
          text: { 
            type: 'mrkdwn', 
            text: '*Cancel Session* ❌\n\nAre you sure you want to cancel this coaching session?' 
          }
        },
        {
          type: 'actions',
          elements: [
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Confirm Cancellation' },
              style: 'danger',
              value: 'confirm_session_cancellation',
              action_id: 'confirm_session_cancellation'
            },
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Keep Session' },
              value: 'keep_session',
              action_id: 'keep_session'
            }
          ]
        }
      ]
    });
  }
};