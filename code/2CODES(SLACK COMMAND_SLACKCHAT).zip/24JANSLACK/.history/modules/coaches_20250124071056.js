const coaches = [
  {
    id: '1',
    name: 'Alice Thompson',
    expertise: ['Leadership', 'Career Development'],
    rating: 4.8,
    languages: ['English', 'Spanish']
  },
  {
    id: '2',
    name: 'Bob Rodriguez',
    expertise: ['Career Growth', 'Communication Skills'],
    rating: 4.7,
    languages: ['English', 'Portuguese']
  }
];

module.exports = {
  searchCoaches: () => ({
    text: 'Available Coaches',
    blocks: [
      {
        type: 'section',
        text: { type: 'mrkdwn', text: '*Available Coaches* 👥' }
      },
      ...coaches.map(coach => ({
        type: 'section',
        text: { 
          type: 'mrkdwn', 
          text: `*${coach.name}* (Rating: ${coach.rating}/5)\n_Expertise:_ ${coach.expertise.join(', ')}` 
        }
      }))
    ]
  }),

  recommendCoaches: () => ({
    text: 'Recommended Coaches',
    blocks: [
      {
        type: 'section',
        text: { type: 'mrkdwn', text: '*Top Recommended Coaches* 🌟' }
      },
      ...coaches
        .filter(coach => coach.rating >= 4.7)
        .map(coach => ({
          type: 'section',
          text: { 
            type: 'mrkdwn', 
            text: `*${coach.name}* (Rating: ${coach.rating}/5)\n_Expertise:_ ${coach.expertise.join(', ')}` 
          }
        }))
    ]
  })
};