const sessions = [];

module.exports = {
  scheduleSession: async (body, say) => {
    await say({
      text: 'Schedule a Coaching Session',
      blocks: [
        {
          type: 'section',
          text: { 
            type: 'mrkdwn', 
            text: '*Schedule a Coaching Session* 📅\nSelect a date and time:' 
          }
        }
      ]
    });
  },

  listSessions: () => ({
    text: 'Your Coaching Sessions',
    blocks: [
      {
        type: 'section',
        text: { type: 'mrkdwn', text: '*Scheduled Sessions* 📆' }
      },
      ...(sessions.length > 0 
        ? sessions.map(session => ({
            type: 'section',
            text: { type: 'mrkdwn', text: `• ${session}` }
          }))
        : [{
            type: 'section',
            text: { type: 'mrkdwn', text: 'No sessions scheduled yet. Book your first session!' }
          }]
      )
    ]
  })
};