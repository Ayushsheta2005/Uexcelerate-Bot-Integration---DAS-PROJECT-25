module.exports = {
  generateMainMenu: () => ({
    text: 'Coaching Companion Main Menu',  // Fallback text for notifications
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: '*Welcome to Coaching Companion* 🚀\nChoose an option to get started:',
        },
      },
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: { type: 'plain_text', text: 'Coaches 👥' },
            value: 'coaches_menu',
            action_id: 'coaches_menu_button',  // Unique action_id
          },
          {
            type: 'button',
            text: { type: 'plain_text', text: 'Goals 🎯' },
            value: 'goals_menu',
            action_id: 'goals_menu_button',  // Unique action_id
          },
          {
            type: 'button',
            text: { type: 'plain_text', text: 'Sessions 📅' },
            value: 'sessions_menu',
            action_id: 'sessions_menu_button',  // Unique action_id
          },
        ],
      },
    ],
  }),

  handleMainMenuSelection: async (body, say) => {
    const selection = body.actions[0].value;

    const menuResponses = {
      'coaches_menu': {
        text: 'Coaches Menu',
        blocks: [
          {
            type: 'section',
            text: { type: 'mrkdwn', text: '*Coaches Menu* 👥' },
          },
          {
            type: 'actions',
            elements: [
              {
                type: 'button',
                text: { type: 'plain_text', text: 'View Coaches' },
                value: 'view_coaches',
                action_id: 'view_coaches_button',
              },
              {
                type: 'button',
                text: { type: 'plain_text', text: 'Get Recommendations' },
                value: 'recommend_coaches',
                action_id: 'recommend_coaches_button',
              },
            ],
          },
        ],
      },
      'goals_menu': {
        text: 'Goals Menu',
        blocks: [
          {
            type: 'section',
            text: { type: 'mrkdwn', text: '*Goals Menu* 🎯' },
          },
          {
            type: 'actions',
            elements: [
              {
                type: 'button',
                text: { type: 'plain_text', text: 'Create Goal' },
                value: 'create_goal',
                action_id: 'create_goal_button',
              },
              {
                type: 'button',
                text: { type: 'plain_text', text: 'List Goals' },
                value: 'list_goals',
                action_id: 'list_goals_button',
              },
            ],
          },
        ],
      },
      'sessions_menu': {
        text: 'Sessions Menu',
        blocks: [
          {
            type: 'section',
            text: { type: 'mrkdwn', text: '*Sessions Menu* 📅' },
          },
          {
            type: 'actions',
            elements: [
              {
                type: 'button',
                text: { type: 'plain_text', text: 'Schedule Session' },
                value: 'schedule_session',
                action_id: 'schedule_session_button',
              },
              {
                type: 'button',
                text: { type: 'plain_text', text: 'List Sessions' },
                value: 'list_sessions',
                action_id: 'list_sessions_button',
              },
            ],
          },
        ],
      }
    };

    const response = menuResponses[selection];
    if (response) {
      await say(response);
    }
  }
};