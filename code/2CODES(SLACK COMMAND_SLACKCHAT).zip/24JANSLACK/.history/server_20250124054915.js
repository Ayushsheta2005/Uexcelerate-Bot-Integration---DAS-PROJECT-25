require('dotenv').config();
const express = require('express');
const { App } = require('@slack/bolt');

// Initialize the Express app
const app = express();

// Middleware to parse JSON payloads
app.use(express.json());

// Slack App Initialization
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
});

// Sample data (using some mock data for demonstration purposes)
const coaches = [
  { id: 1, name: 'Alice', expertise: 'Leadership', availability: 'Weekdays', rating: 4.5, location: 'New York', languages: ['English', 'Spanish'] },
  { id: 2, name: 'Bob', expertise: 'Career Growth', availability: 'Weekends', rating: 4.7, location: 'London', languages: ['English', 'French'] },
  // more coaches
];
const goals = [];
const actions = [];
const sessions = [];

// Shared functions for beautiful formatting
const searchCoaches = () => {
  return {
    blocks: [
      {
        type: 'section',
        block_id: 'coaches_list',
        text: {
          type: 'mrkdwn',
          text: '*Available Coaches*:\nHere are some great coaches you can choose from:',
        },
      },
      ...coaches.map(coach => ({
        type: 'section',
        fields: [
          { type: 'mrkdwn', text: `*Name:* ${coach.name}` },
          { type: 'mrkdwn', text: `*Expertise:* ${coach.expertise}` },
          { type: 'mrkdwn', text: `*Rating:* ${coach.rating}` },
          { type: 'mrkdwn', text: `*Availability:* ${coach.availability}` },
          { type: 'mrkdwn', text: `*Location:* ${coach.location}` },
          { type: 'mrkdwn', text: `*Languages:* ${coach.languages.join(', ')}` },
        ],
      })),
      {
        type: 'divider',
      },
    ],
  };
};

const createAction = (userId) => {
  const id = actions.length + 1;
  const action = { id, description: 'New Action', owner: userId, status: 'In Progress' };
  actions.push(action);

  return {
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*Action Created Successfully* 🎯\nID: *${id}*\nDescription: *${action.description}*\nStatus: *${action.status}*`,
        },
      },
      {
        type: 'divider',
      },
    ],
  };
};

const createGoal = (userId) => {
  const id = goals.length + 1;
  const goal = { id, description: 'SMART Goal', owner: userId, targetDate: '2025-02-15', progress: 'In Progress' };
  goals.push(goal);

  return {
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*Goal Created Successfully* 🥅\nID: *${id}*\nDescription: *${goal.description}*\nProgress: *${goal.progress}*\nTarget Date: *${goal.targetDate}*`,
        },
      },
      {
        type: 'divider',
      },
    ],
  };
};

const scheduleSession = (userId) => {
  const id = sessions.length + 1;
  const session = { id, coach: 'Alice', date: '2025-01-30', user: userId };
  sessions.push(session);

  return {
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*Session Scheduled Successfully* 📅\nCoach: *${session.coach}*\nDate: *${session.date}*`,
        },
      },
      {
        type: 'divider',
      },
    ],
  };
};

// Help message with formatting
const helpMessage = () => {
  return {
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*How to Use the Bot* 🤖\nHere are the commands you can use to interact with the bot:`,
        },
      },
      {
        type: 'section',
        fields: [
          { type: 'mrkdwn', text: `*search coach* - View available coaches.` },
          { type: 'mrkdwn', text: `*create action* - Create a coaching action.` },
          { type: 'mrkdwn', text: `*create goal* - Set a SMART goal.` },
          { type: 'mrkdwn', text: `*schedule session* - Schedule a coaching session.` },
          { type: 'mrkdwn', text: `*list coaches* - View detailed list of coaches.` },
          { type: 'mrkdwn', text: `*list goals* - View your goals.` },
          { type: 'mrkdwn', text: `*list actions* - View your actions.` },
        ],
      },
    ],
  };
};

// Slack Bot Handlers
slackApp.message(/search coach/i, async ({ message, say }) => {
  await say(searchCoaches());
});

slackApp.message(/create action/i, async ({ message, say }) => {
  await say(createAction(message.user));
});

slackApp.message(/create goal/i, async ({ message, say }) => {
  await say(createGoal(message.user));
});

slackApp.message(/schedule session/i, async ({ message, say }) => {
  await say(scheduleSession(message.user));
});

slackApp.message(/help/i, async ({ message, say }) => {
  await say(helpMessage());
});

// Add the /slack/events route to handle Slack requests
app.post('/slack/events', async (req, res) => {
  try {
    if (req.body && req.body.type === 'url_verification') {
      return res.json({ challenge: req.body.challenge });
    }

    if (req.body && req.body.event) {
      const { event } = req.body;
      console.log('Slack Event:', event);

      if (event.type === 'message' && event.text) {
        // Bot command handling
        const text = event.text.toLowerCase();

        if (text.includes('search coach')) {
          await slackApp.client.chat.postMessage({
            channel: event.channel,
            blocks: searchCoaches().blocks,
          });
        } else if (text.includes('create action')) {
          await slackApp.client.chat.postMessage({
            channel: event.channel,
            blocks: createAction(event.user).blocks,
          });
        } else if (text.includes('create goal')) {
          await slackApp.client.chat.postMessage({
            channel: event.channel,
            blocks: createGoal(event.user).blocks,
          });
        } else if (text.includes('schedule session')) {
          await slackApp.client.chat.postMessage({
            channel: event.channel,
            blocks: scheduleSession(event.user).blocks,
          });
        } else if (text.includes('help')) {
          await slackApp.client.chat.postMessage({
            channel: event.channel,
            blocks: helpMessage().blocks,
          });
        }
      }
    }
    res.status(200).send();
  } catch (error) {
    console.error('Error handling Slack event:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Start the Slack App
(async () => {
  try {
    const slackPort = process.env.SLACK_PORT || 3001;
    await slackApp.start(slackPort);
    console.log(`⚡️ Slack app is running on port ${slackPort}`);
  } catch (error) {
    console.error('Error starting Slack app:', error);
  }
})();

// Start the Express server for health check and event handling
const port = process.env.PORT || 3000;
app.get('/', (req, res) => res.send('Bot is running! 🚀'));
app.listen(port, () => {
  console.log(`🌐 Server is running on port ${port}`);
});
