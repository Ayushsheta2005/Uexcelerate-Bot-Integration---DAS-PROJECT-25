require('dotenv').config();
const express = require('express');
const { App } = require('@slack/bolt');

// Initialize the Express app
const app = express();

// Middleware to parse JSON payloads
app.use(express.json());

// Slack App Initialization
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
});

// Sample data (Extended version)
const coaches = [
  { id: 1, name: 'Alice', expertise: 'Leadership', availability: 'Weekdays', rating: 4.5, location: 'New York', languages: ['English', 'Spanish'] },
  { id: 2, name: 'Bob', expertise: 'Career Growth', availability: 'Weekends', rating: 4.7, location: 'London', languages: ['English', 'French'] },
  { id: 3, name: 'Charlie', expertise: 'Mindfulness', availability: 'Weekdays', rating: 4.9, location: 'Berlin', languages: ['English', 'German'] },
  { id: 4, name: 'David', expertise: 'Time Management', availability: 'Weekdays', rating: 4.6, location: 'San Francisco', languages: ['English'] },
  { id: 5, name: 'Eva', expertise: 'Career Change', availability: 'Weekends', rating: 4.8, location: 'Paris', languages: ['English', 'French'] },
  // Add more coaches here...
];

const goals = [
  { id: 1, description: 'Improve leadership skills', owner: 1, targetDate: '2025-02-15', progress: 'In Progress' },
  { id: 2, description: 'Launch new project', owner: 2, targetDate: '2025-03-01', progress: 'Not Started' },
  { id: 3, description: 'Master mindfulness', owner: 3, targetDate: '2025-04-10', progress: 'Completed' },
  // Add more goals here...
];

const actions = [
  { id: 1, description: 'Read leadership books', owner: 1, status: 'In Progress' },
  { id: 2, description: 'Attend time management seminar', owner: 2, status: 'Not Started' },
  { id: 3, description: 'Meditate daily', owner: 3, status: 'Completed' },
  // Add more actions here...
];

const sessions = [
  { id: 1, coach: 'Alice', date: '2025-02-10', user: 1 },
  { id: 2, coach: 'Bob', date: '2025-03-05', user: 2 },
  { id: 3, coach: 'Charlie', date: '2025-02-25', user: 3 },
  // Add more sessions here...
];

// Shared functions for Slack bot
const searchCoaches = () => {
  return coaches
    .map(
      (coach) =>
        `👤 ${coach.name} | Expertise: ${coach.expertise} | Rating: ${coach.rating} | Availability: ${coach.availability} | Location: ${coach.location} | Languages: ${coach.languages.join(', ')}`
    )
    .join('\n');
};

const createAction = (userId) => {
  const id = actions.length + 1;
  const action = { id, description: 'New Action', owner: userId };
  actions.push(action);
  return `Action created successfully! 🎯\nDetails: ID ${id}, Description: ${action.description}`;
};

const createGoal = (userId) => {
  const id = goals.length + 1;
  const goal = { id, description: 'SMART Goal', owner: userId };
  goals.push(goal);
  return `Goal created successfully! 🥅\nDetails: ID ${id}, Description: ${goal.description}`;
};

const scheduleSession = (userId) => {
  const id = sessions.length + 1;
  const session = { id, coach: 'Alice', date: '2025-01-30', user: userId };
  sessions.push(session);
  return `Session scheduled successfully! 📅\nCoach: ${session.coach}, Date: ${session.date}`;
};

// New extended commands
const listAllCoaches = () => {
  return coaches
    .map(
      (coach) =>
        `👤 ${coach.name} | Expertise: ${coach.expertise} | Rating: ${coach.rating} | Availability: ${coach.availability} | Location: ${coach.location} | Languages: ${coach.languages.join(', ')}`
    )
    .join('\n');
};

const listAllGoals = () => {
  return goals
    .map(
      (goal) =>
        `🥅 Goal: ${goal.description} | Target Date: ${goal.targetDate} | Progress: ${goal.progress}`
    )
    .join('\n');
};

const listAllActions = () => {
  return actions
    .map(
      (action) =>
        `🎯 Action: ${action.description} | Status: ${action.status}`
    )
    .join('\n');
};

const sortCoachesByRating = () => {
  const sortedCoaches = [...coaches].sort((a, b) => b.rating - a.rating);
  return sortedCoaches
    .map(
      (coach) =>
        `👤 ${coach.name} | Expertise: ${coach.expertise} | Rating: ${coach.rating}`
    )
    .join('\n');
};

// Add the /slack/events route to handle Slack requests
app.post('/slack/events', async (req, res) => {
  try {
    if (req.body && req.body.type === 'url_verification') {
      return res.json({ challenge: req.body.challenge });
    }

    if (req.body && req.body.event) {
      const { event } = req.body;
      console.log('Slack Event:', event);

      if (event.type === 'message' && event.text) {
        // Bot command handling
        const text = event.text.toLowerCase();

        if (text.includes('search coach')) {
          await slackApp.client.chat.postMessage({
            channel: event.channel,
            text: searchCoaches()
          });
        } else if (text.includes('create action')) {
          await slackApp.client.chat.postMessage({
            channel: event.channel,
            text: createAction(event.user)
          });
        } else if (text.includes('create goal')) {
          await slackApp.client.chat.postMessage({
            channel: event.channel,
            text: createGoal(event.user)
          });
        } else if (text.includes('schedule session')) {
          await slackApp.client.chat.postMessage({
            channel: event.channel,
            text: scheduleSession(event.user)
          });
        } else if (text.includes('list coaches')) {
          await slackApp.client.chat.postMessage({
            channel: event.channel,
            text: listAllCoaches()
          });
        } else if (text.includes('list goals')) {
          await slackApp.client.chat.postMessage({
            channel: event.channel,
            text: listAllGoals()
          });
        } else if (text.includes('list actions')) {
          await slackApp.client.chat.postMessage({
            channel: event.channel,
            text: listAllActions()
          });
        } else if (text.includes('sort coaches by rating')) {
          await slackApp.client.chat.postMessage({
            channel: event.channel,
            text: sortCoachesByRating()
          });
        } else if (text.includes('help')) {
          await slackApp.client.chat.postMessage({
            channel: event.channel,
            text: `Here are the commands you can use:
  - "search coach": View all available coaches.
  - "create action": Create a coaching action.
  - "create goal": Set a SMART goal.
  - "schedule session": Schedule a new coaching session.
  - "list coaches": View all coaches with detailed information.
  - "list goals": View all your goals.
  - "list actions": View all your actions.
  - "sort coaches by rating": View coaches sorted by their rating.`
          });
        }
      }
    }
    res.status(200).send();
  } catch (error) {
    console.error('Error handling Slack event:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Start the Slack App
(async () => {
  try {
    const slackPort = process.env.SLACK_PORT || 3001;
    await slackApp.start(slackPort);
    console.log(`⚡️ Slack app is running on port ${slackPort}`);
  } catch (error) {
    console.error('Error starting Slack app:', error);
  }
})();

// Start the Express server for health check and event handling
const port = process.env.PORT || 3000;
app.get('/', (req, res) => res.send('Bot is running! 🚀'));
app.listen(port, () => {
  console.log(`🌐 Server is running on port ${port}`);
});
