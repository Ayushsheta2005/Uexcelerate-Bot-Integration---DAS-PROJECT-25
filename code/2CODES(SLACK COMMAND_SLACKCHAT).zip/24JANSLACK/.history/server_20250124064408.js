require('dotenv').config();
const { App } = require('@slack/bolt');

// Initialize Slack App
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,  // Bot token from environment variables
  signingSecret: process.env.SLACK_SIGNING_SECRET,  // Signing secret from environment variables
});

// Sample data (mocked for this example)
const coaches = [
  { id: 1, name: 'Alice', expertise: 'Leadership', availability: 'Weekdays', rating: 4.5, location: 'New York', languages: ['English', 'Spanish'] },
  { id: 2, name: 'Bob', expertise: 'Career Growth', availability: 'Weekends', rating: 4.7, location: 'London', languages: ['English', 'French'] },
];

const goals = ['Goal 1: Become a better leader', 'Goal 2: Improve career growth'];

const sessions = [];

// Function to return a formatted list of available coaches
const searchCoaches = () => {
  return {
    blocks: [
      {
        type: 'section',
        block_id: 'coaches_list',
        text: {
          type: 'mrkdwn',
          text: '*Available Coaches*:\nHere are some great coaches you can choose from:',
        },
      },
      ...coaches.map(coach => ({
        type: 'section',
        fields: [
          { type: 'mrkdwn', text: `*Name:* ${coach.name}` },
          { type: 'mrkdwn', text: `*Expertise:* ${coach.expertise}` },
          { type: 'mrkdwn', text: `*Rating:* ${coach.rating}` },
          { type: 'mrkdwn', text: `*Availability:* ${coach.availability}` },
          { type: 'mrkdwn', text: `*Location:* ${coach.location}` },
          { type: 'mrkdwn', text: `*Languages:* ${coach.languages.join(', ')}` },
        ],
      })),
      {
        type: 'divider',
      },
    ],
  };
};

// Function to return a list of goals
const showGoals = () => {
  return {
    blocks: [
      {
        type: 'section',
        block_id: 'goals_list',
        text: {
          type: 'mrkdwn',
          text: '*Goals*:\nHere are the goals that have been set:',
        },
      },
      ...goals.map(goal => ({
        type: 'section',
        fields: [
          { type: 'mrkdwn', text: `*Goal:* ${goal}` },
        ],
      })),
      {
        type: 'divider',
      },
    ],
  };
};

// Function to return a list of scheduled sessions
const showSessions = () => {
  return {
    blocks: [
      {
        type: 'section',
        block_id: 'sessions_list',
        text: {
          type: 'mrkdwn',
          text: '*Scheduled Sessions*:\nHere are the sessions that have been scheduled:',
        },
      },
      ...sessions.map(session => ({
        type: 'section',
        fields: [
          { type: 'mrkdwn', text: `*Coach:* ${session.coach}` },
          { type: 'mrkdwn', text: `*Date:* ${session.date}` },
        ],
      })),
      {
        type: 'divider',
      },
    ],
  };
};

// Function to ask for goal or action type
const askGoalOrAction = () => {
  return {
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: 'What would you like to do? Choose one of the options below:',
        },
      },
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'Create Goal',
            },
            value: 'create_goal',
            action_id: 'create_goal',
          },
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'Create Action',
            },
            value: 'create_action',
            action_id: 'create_action',
          },
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'Schedule Session with Coach',
            },
            value: 'schedule_session',
            action_id: 'schedule_session',
          },
        ],
      },
    ],
  };
};

// Slack Bot Handlers
slackApp.message(/create goal/i, async ({ message, say }) => {
  if (message.user !== process.env.SLACK_BOT_USER_ID && !message.subtype) {
    await say(showGoals());
  }
});

slackApp.message(/create action/i, async ({ message, say }) => {
  if (message.user !== process.env.SLACK_BOT_USER_ID && !message.subtype) {
    await say(askGoalOrAction());
  }
});

slackApp.message(/schedule session/i, async ({ message, say }) => {
  if (message.user !== process.env.SLACK_BOT_USER_ID && !message.subtype) {
    await say(searchCoaches());
  }
});

slackApp.message(/help/i, async ({ message, say }) => {
  if (message.user !== process.env.SLACK_BOT_USER_ID && !message.subtype) {
    await say({
      text: 'Here are some commands you can try:\n- Create Goal\n- Create Action\n- Schedule Session\n- Show Goals\n- Show Sessions',
    });
  }
});

// Handle interactive button clicks
slackApp.action('create_goal', async ({ body, ack, say }) => {
  await ack();
  await say({
    text: 'Please provide a description of your SMART goal:',
  });
});

slackApp.action('create_action', async ({ body, ack, say }) => {
  await ack();
  await say({
    text: 'Please provide a description of your coaching action:',
  });
});

slackApp.action('schedule_session', async ({ body, ack, say }) => {
  await ack();
  await say({
    text: 'Which coach would you like to schedule a session with?',
    attachments: [
      {
        text: 'Choose a coach from the list below:',
        callback_id: 'coach_selection',
        actions: coaches.map(coach => ({
          name: 'coach',
          text: coach.name,
          type: 'button',
          value: coach.name,
        })),
      },
    ],
  });
});

slackApp.action('coach_selection', async ({ body, ack, say }) => {
  await ack();
  const selectedCoach = body.actions[0].value;
  const session = {
    id: sessions.length + 1,
    coach: selectedCoach,
    date: '2025-01-30',
    user: body.user.id,
  };
  sessions.push(session);
  await say(showSessions());
});

// Start the Slack app
(async () => {
  try {
    await slackApp.start();
    console.log('⚡️ Slack bot is running!');
  } catch (error) {
    console.error('Error starting Slack app:', error);
  }
})();
