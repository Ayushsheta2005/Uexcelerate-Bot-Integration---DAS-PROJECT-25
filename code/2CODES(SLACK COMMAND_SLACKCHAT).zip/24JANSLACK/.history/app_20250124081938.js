require('dotenv').config();
const { App } = require('@slack/bolt');
const express = require('express');

// Initialize Slack Bolt app
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET
});

// Initialize Express app
const expressApp = express();
expressApp.use(express.json());

// Define the Slack message listener for "hello"
slackApp.message('hello', async ({ message, say }) => {
  await say({
    text: 'Click the button!',
    blocks: [
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: { type: 'plain_text', text: 'Click Me' },
            action_id: 'sample_button',
            value: 'button_clicked'
          }
        ]
      }
    ]
  });
});

// Define action listener for the button click
slackApp.action('sample_button', async ({ body, ack, say }) => {
  await ack();
  await say(`Button was clicked by <@${body.user.id}>!`);
  
  // Notify an external service (example usage of the third route)
  const userId = body.user.id;
  await fetch(`http://localhost:4000/notify?userId=${userId}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ event: 'button_clicked' })
  });
});

// Express route for external service
expressApp.post('/notify', (req, res) => {
  const { userId, event } = req.body;
  console.log(`Received notification: User ${userId} triggered event ${event}`);
  res.status(200).send('Notification received');
});

// Start both Slack Bolt app and Express server
(async () => {
  await slackApp.start(process.env.PORT || 3000);
  console.log('⚡️ Bolt app started on Slack');
  
  const expressPort = 4000;
  expressApp.listen(expressPort, () => {
    console.log(`🌐 Express app started on http://localhost:${expressPort}`);
  });
})();
