require('dotenv').config();
const { App } = require('@slack/bolt');
const express = require('express');

// Initialize Slack Bolt app
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET
});

// Initialize Express app for handling slash command request
const expressApp = express();
expressApp.use(express.json());

// Slash Command Handler
slackApp.command('/coachbot', async ({ ack, body, respond }) => {
  await ack();  // Acknowledge the slash command request

  // Open a modal with a feedback form
  try {
    await slackApp.client.views.open({
      trigger_id: body.trigger_id,
      view: {
        type: 'modal',
        callback_id: 'feedback_modal',
        title: {
          type: 'plain_text',
          text: 'Feedback Form'
        },
        blocks: [
          {
            type: 'section',
            block_id: 'feedback_section',
            text: {
              type: 'mrkdwn',
              text: 'Please provide your feedback below:'
            },
            accessory: {
              type: 'plain_text_input',
              action_id: 'feedback_input',
              placeholder: {
                type: 'plain_text',
                text: 'Enter your feedback here...'
              },
              multiline: true
            }
          }
        ]
      }
    });
  } catch (error) {
    console.error('Error opening modal:', error);
  }
});

// Modal submission handler
slackApp.view('feedback_modal', async ({ ack, body, view, say }) => {
  await ack();  // Acknowledge the modal submission
  
  const feedback = view.state.values.feedback_section.feedback_input.value;
  console.log('Feedback submitted:', feedback);  // Log the feedback to the console
  
  // Respond with a confirmation message
  await say(`Thank you for your feedback: "${feedback}"`);
});

// Start both Slack Bolt app and Express server
(async () => {
  try {
    await slackApp.start(process.env.PORT || 3000);
    console.log('⚡️ Bolt app started on Slack');
  } catch (error) {
    console.error('Error starting Slack app:', error);
  }

  const expressPort = 4000;
  expressApp.listen(expressPort, () => {
    console.log(`🌐 Express app started on http://localhost:${expressPort}`);
  });
})();
