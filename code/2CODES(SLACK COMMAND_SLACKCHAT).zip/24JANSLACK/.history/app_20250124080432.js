require('dotenv').config();
const { App } = require('@slack/bolt');
const { 
  searchCoaches, 
  getCoachDetails, 
  recommendCoaches 
} = require('./modules/coaches');
const { 
  createGoal, 
  listGoals, 
  updateGoal, 
  deleteGoal 
} = require('./modules/goals');
const { 
  scheduleSession, 
  listSessions, 
  cancelSession 
} = require('./modules/schedules');
const { 
  generateMainMenu,
  handleMainMenuSelection 
} = require('./modules/menu.js');

// Initialize Slack App
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
});

// Main Menu Interaction
slackApp.message(/start|menu/i, async ({ message, say }) => 
  {

    await say(generateMainMenu());

});

slackApp.message(/view_coaches/i, async ({ message, say }) => 
  {
  
      await say(searchCoaches());
  
  }
);


// Main Menu Action Handler
slackApp.action('main_menu_selection', async ({ body, ack, say }) => {
  await ack();
  await handleMainMenuSelection(body, say);
});

// Coaches Interactions
slackApp.action('view_coaches', async ({ body, ack, say }) => {
  await ack();
  await say(searchCoaches());
});

slackApp.action('recommend_coaches', async ({ body, ack, say }) => {
  await ack();
  await say(recommendCoaches());
});

slackApp.action('coach_details', async ({ body, ack, say }) => {
  await ack();
  const coachId = body.actions[0].value;
  await say(getCoachDetails(coachId));
});

// Goals Interactions
slackApp.action('create_goal', async ({ body, ack, say }) => {
  await ack();
  await createGoal(body, say);
});

slackApp.action('list_goals', async ({ body, ack, say }) => {
  await ack();
  await say(listGoals());
});

slackApp.action('update_goal', async ({ body, ack, say }) => {
  await ack();
  await updateGoal(body, say);
});

slackApp.action('delete_goal', async ({ body, ack, say }) => {
  await ack();
  await deleteGoal(body, say);
});

// Sessions Interactions
slackApp.action('schedule_session', async ({ body, ack, say }) => {
  await ack();
  await scheduleSession(body, say);
});

slackApp.action('list_sessions', async ({ body, ack, say }) => {
  await ack();
  await say(listSessions());
});

slackApp.action('cancel_session', async ({ body, ack, say }) => {
  await ack();
  await cancelSession(body, say);
});

// Error Handler
slackApp.error(async (error) => {
  console.error('Slack Bot Error:', error);
});

// Start the Slack app
(async () => {
  try {
    await slackApp.start();
    console.log('⚡️ Coaching Bot is running!');
  } catch (error) {
    console.error('Error starting Slack app:', error);
  }
})();