require('dotenv').config();
const { App } = require('@slack/bolt');

const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET
});

slackApp.message(/yo slack/i, async ({ message, say }) => {
  await say('Yo! What\'s up?');
});



slackApp.message('/hello/i', async ({ message, say }) => {
  await say({
    blocks: [
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: { type: 'plain_text', text: 'Click Me' },
            action_id: 'sample_button',
            value: 'button_clicked'
          }
        ]
      }
    ]
  });
});

slackApp.action('sample_button', async ({ body, ack, say }) => {
  await ack();
  await say(`Button clicked by <@${body.user.id}>!`);
});