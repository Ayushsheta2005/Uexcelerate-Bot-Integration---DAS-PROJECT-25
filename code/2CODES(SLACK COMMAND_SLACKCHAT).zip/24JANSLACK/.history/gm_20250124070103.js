const goals = [];

module.exports = {
  createGoal: async (body, say) => {
    await say({
      blocks: [
        {
          type: 'section',
          text: { 
            type: 'mrkdwn', 
            text: '*Create a SMART Goal* 🎯\n\nPlease provide:\n• Specific objective\n• Measurable outcome\n• Achievable target\n• Relevant purpose\n• Time-bound deadline' 
          }
        },
        {
          type: 'actions',
          elements: [
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Cancel' },
              value: 'cancel_goal_creation',
              action_id: 'cancel_goal'
            }
          ]
        }
      ]
    });
  },

  listGoals: () => ({
    blocks: [
      {
        type: 'section',
        text: { type: 'mrkdwn', text: '*Your Goals* 🏆' }
      },
      ...(goals.length > 0 
        ? goals.map((goal, index) => ({
            type: 'section',
            text: { 
              type: 'mrkdwn', 
              text: `*Goal ${index + 1}:* ${goal.title}\n_Status:_ ${goal.status}\n*Deadline:* ${goal.deadline}` 
            },
            accessory: {
              type: 'button',
              text: { type: 'plain_text', text: 'Update' },
              value: `update_goal_${index}`,
              action_id: 'update_goal'
            }
          }))
        : [{
            type: 'section',
            text: { type: 'mrkdwn', text: 'No goals created yet. Start by setting your first goal!' }
          }]
      )
    ]
  }),

  updateGoal: async (body, say) => {
    await say({
      blocks: [
        {
          type: 'section',
          text: { 
            type: 'mrkdwn', 
            text: '*Update Goal* 🔧\n\nChoose what you want to modify:' 
          }
        },
        {
          type: 'actions',
          elements: [
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Title' },
              value: 'update_goal_title',
              action_id: 'update_goal_title'
            },
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Status' },
              value: 'update_goal_status',
              action_id: 'update_goal_status'
            },
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Deadline' },
              value: 'update_goal_deadline',
              action_id: 'update_goal_deadline'
            }
          ]
        }
      ]
    });
  },

  deleteGoal: async (body, say) => {
    await say({
      blocks: [
        {
          type: 'section',
          text: { 
            type: 'mrkdwn', 
            text: '*Delete Goal* 🗑️\n\nAre you sure you want to delete this goal?' 
          }
        },
        {
          type: 'actions',
          elements: [
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Confirm Delete' },
              style: 'danger',
              value: 'confirm_goal_deletion',
              action_id: 'confirm_goal_deletion'
            },
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Cancel' },
              value: 'cancel_goal_deletion',
              action_id: 'cancel_goal_deletion'
            }
          ]
        }
      ]
    });
  }
};