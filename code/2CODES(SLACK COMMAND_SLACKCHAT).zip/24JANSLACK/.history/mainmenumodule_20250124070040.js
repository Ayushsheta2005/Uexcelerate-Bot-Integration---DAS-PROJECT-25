module.exports = {
    generateMainMenu: () => ({
      blocks: [
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: '*Welcome to Coaching Companion* 🚀\nChoose an option to get started:',
          },
        },
        {
          type: 'actions',
          block_id: 'main_menu_selection',
          elements: [
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Coaches 👥' },
              value: 'coaches_menu',
              action_id: 'main_menu_selection',
            },
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Goals 🎯' },
              value: 'goals_menu',
              action_id: 'main_menu_selection',
            },
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Sessions 📅' },
              value: 'sessions_menu',
              action_id: 'main_menu_selection',
            },
          ],
        },
      ],
    }),
  
    handleMainMenuSelection: async (body, say) => {
      const selection = body.actions[0].value;
  
      switch (selection) {
        case 'coaches_menu':
          await say({
            blocks: [
              {
                type: 'section',
                text: { type: 'mrkdwn', text: '*Coaches Menu* 👥' },
              },
              {
                type: 'actions',
                elements: [
                  {
                    type: 'button',
                    text: { type: 'plain_text', text: 'View Coaches' },
                    value: 'view_coaches',
                    action_id: 'view_coaches',
                  },
                  {
                    type: 'button',
                    text: { type: 'plain_text', text: 'Get Coach Recommendations' },
                    value: 'recommend_coaches',
                    action_id: 'recommend_coaches',
                  },
                ],
              },
            ],
          });
          break;
        
        case 'goals_menu':
          await say({
            blocks: [
              {
                type: 'section',
                text: { type: 'mrkdwn', text: '*Goals Menu* 🎯' },
              },
              {
                type: 'actions',
                elements: [
                  {
                    type: 'button',
                    text: { type: 'plain_text', text: 'Create Goal' },
                    value: 'create_goal',
                    action_id: 'create_goal',
                  },
                  {
                    type: 'button',
                    text: { type: 'plain_text', text: 'List Goals' },
                    value: 'list_goals',
                    action_id: 'list_goals',
                  },
                ],
              },
            ],
          });
          break;
        
        case 'sessions_menu':
          await say({
            blocks: [
              {
                type: 'section',
                text: { type: 'mrkdwn', text: '*Sessions Menu* 📅' },
              },
              {
                type: 'actions',
                elements: [
                  {
                    type: 'button',
                    text: { type: 'plain_text', text: 'Schedule Session' },
                    value: 'schedule_session',
                    action_id: 'schedule_session',
                  },
                  {
                    type: 'button',
                    text: { type: 'plain_text', text: 'List Sessions' },
                    value: 'list_sessions',
                    action_id: 'list_sessions',
                  },
                ],
              },
            ],
          });
          break;
      }
    }
  };