// Sample goals data
const goals = ['Goal 1: Become a better leader', 'Goal 2: Improve career growth'];

// Function to return a list of goals
const showGoals = () => {
  return {
    blocks: [
      {
        type: 'section',
        block_id: 'goals_list',
        text: {
          type: 'mrkdwn',
          text: '*Goals*:\nHere are the goals that have been set:',
        },
      },
      ...goals.map(goal => ({
        type: 'section',
        fields: [
          { type: 'mrkdwn', text: `*Goal:* ${goal}` },
        ],
      })),
      {
        type: 'divider',
      },
    ],
  };
};

// Function to ask for goal or action type
const askGoalOrAction = () => {
  return {
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: 'What would you like to do? Choose one of the options below:',
        },
      },
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'Create Goal',
            },
            value: 'create_goal',
            action_id: 'create_goal',
          },
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'Create Action',
            },
            value: 'create_action',
            action_id: 'create_action',
          },
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'Schedule Session with Coach',
            },
            value: 'schedule_session',
            action_id: 'schedule_session',
          },
        ],
      },
    ],
  };
};

module.exports = {
  goals,
  showGoals,
  askGoalOrAction,
};