require('dotenv').config();
const express = require('express');
const { App, ExpressReceiver } = require('@slack/bolt');

// Create an express receiver
const expressReceiver = new ExpressReceiver({
  signingSecret: process.env.SLACK_SIGNING_SECRET,
  installerOptions: {
    directInstall: true,
  },
});

// Initialize Slack App with Express Receiver
const slackApp = new App({
  receiver: expressReceiver,
  token: process.env.SLACK_BOT_TOKEN,
});

// Import modules
const { 
  searchCoaches, 
  getCoachDetails, 
  recommendCoaches 
} = require('./modules/coaches');
const { 
  createGoal, 
  listGoals, 
  updateGoal, 
  deleteGoal 
} = require('./modules/goals');
const { 
  scheduleSession, 
  listSessions, 
  cancelSession 
} = require('./modules/schedules');
const { 
  generateMainMenu,
  handleMainMenuSelection 
} = require('./modules/menu.js');

// Main Menu Interaction
slackApp.message(/start|menu/i, async ({ message, say }) => {
  await say(generateMainMenu());
});

// Slack Action Handlers
slackApp.action('main_menu_selection', async ({ body, ack, say }) => {
  await ack();
  await handleMainMenuSelection(body, say);
});

// Coaches Interactions
slackApp.action('view_coaches', async ({ body, ack, say }) => {
  await ack();
  await say(searchCoaches());
});

slackApp.action('recommend_coaches', async ({ body, ack, say }) => {
  await ack();
  await say(recommendCoaches());
});

slackApp.action('coach_details', async ({ body, ack, say }) => {
  await ack();
  const coachId = body.actions[0].value;
  await say(getCoachDetails(coachId));
});

// Goals Interactions
slackApp.action('create_goal', async ({ body, ack, say }) => {
  await ack();
  await createGoal(body, say);
});

slackApp.action('list_goals', async ({ body, ack, say }) => {
  await ack();
  await say(listGoals());
});

slackApp.action('update_goal', async ({ body, ack, say }) => {
  await ack();
  await updateGoal(body, say);
});

slackApp.action('delete_goal', async ({ body, ack, say }) => {
  await ack();
  await deleteGoal(body, say);
});

// Sessions Interactions
slackApp.action('schedule_session', async ({ body, ack, say }) => {
  await ack();
  await scheduleSession(body, say);
});

slackApp.action('list_sessions', async ({ body, ack, say }) => {
  await ack();
  await say(listSessions());
});

slackApp.action('cancel_session', async ({ body, ack, say }) => {
  await ack();
  await cancelSession(body, say);
});

// Error Handler
slackApp.error(async (error) => {
  console.error('Slack Bot Error:', error);
});

// Create Express app
const app = expressReceiver.app;
const port = process.env.PORT || 3000;

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

// Start the Slack app
(async () => {
  try {
    await slackApp.start(port);
    console.log('⚡️ Coaching Bot is running!');
  } catch (error) {
    console.error('Error starting Slack app:', error);
  }
})();