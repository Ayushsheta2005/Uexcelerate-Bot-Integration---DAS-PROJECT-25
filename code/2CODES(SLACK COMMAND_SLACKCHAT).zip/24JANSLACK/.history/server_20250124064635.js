require('dotenv').config();
const { App } = require('@slack/bolt');

// Initialize Slack App
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,  // Bot token from environment variables
  signingSecret: process.env.SLACK_SIGNING_SECRET,  // Signing secret from environment variables
});

// Sample data (mocked for this example)
const coaches = [
  { id: 1, name: 'Alice', expertise: 'Leadership', availability: 'Weekdays', rating: 4.5, location: 'New York', languages: ['English', 'Spanish'] },
  { id: 2, name: 'Bob', expertise: 'Career Growth', availability: 'Weekends', rating: 4.7, location: 'London', languages: ['English', 'French'] },
];

const goals = [
  { user: 'user123', goal: 'Become a better leader', type: 'Leadership', timeframe: '3 months' },
  { user: 'user456', goal: 'Improve career growth', type: 'Career Growth', timeframe: '6 months' },
];

const sessions = [];

// Helper functions
const searchCoaches = () => {
  return {
    blocks: [
      {
        type: 'section',
        block_id: 'coaches_list',
        text: {
          type: 'mrkdwn',
          text: '*Available Coaches*:\nHere are some amazing coaches you can choose from:',
        },
      },
      ...coaches.map(coach => ({
        type: 'section',
        fields: [
          { type: 'mrkdwn', text: `*Name:* ${coach.name}` },
          { type: 'mrkdwn', text: `*Expertise:* ${coach.expertise}` },
          { type: 'mrkdwn', text: `*Rating:* ${coach.rating}` },
          { type: 'mrkdwn', text: `*Availability:* ${coach.availability}` },
          { type: 'mrkdwn', text: `*Location:* ${coach.location}` },
          { type: 'mrkdwn', text: `*Languages:* ${coach.languages.join(', ')}` },
        ],
      })),
      {
        type: 'divider',
      },
    ],
  };
};

const showGoals = (userId) => {
  const userGoals = goals.filter(goal => goal.user === userId);
  if (userGoals.length === 0) {
    return {
      blocks: [
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: '*Goals*:\nYou haven’t set any goals yet! Let’s create one!',
          },
        },
        {
          type: 'divider',
        },
      ],
    };
  }

  return {
    blocks: [
      {
        type: 'section',
        block_id: 'goals_list',
        text: {
          type: 'mrkdwn',
          text: '*Your Goals*:\nHere are the goals you have set:',
        },
      },
      ...userGoals.map(goal => ({
        type: 'section',
        fields: [
          { type: 'mrkdwn', text: `*Goal:* ${goal.goal}` },
          { type: 'mrkdwn', text: `*Type:* ${goal.type}` },
          { type: 'mrkdwn', text: `*Timeframe:* ${goal.timeframe}` },
        ],
      })),
      {
        type: 'divider',
      },
    ],
  };
};

const showSessions = (userId) => {
  const userSessions = sessions.filter(session => session.user === userId);
  if (userSessions.length === 0) {
    return {
      blocks: [
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: '*Sessions*:\nYou haven’t scheduled any sessions yet! Schedule one now!',
          },
        },
        {
          type: 'divider',
        },
      ],
    };
  }

  return {
    blocks: [
      {
        type: 'section',
        block_id: 'sessions_list',
        text: {
          type: 'mrkdwn',
          text: '*Your Scheduled Sessions*:\nHere are the sessions you’ve scheduled:',
        },
      },
      ...userSessions.map(session => ({
        type: 'section',
        fields: [
          { type: 'mrkdwn', text: `*Coach:* ${session.coach}` },
          { type: 'mrkdwn', text: `*Date:* ${session.date}` },
        ],
      })),
      {
        type: 'divider',
      },
    ],
  };
};

// Function to ask for goal details
const askGoalDetails = () => {
  return {
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: 'Please provide details about your goal:',
        },
      },
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'Leadership Goal',
            },
            value: 'leadership_goal',
            action_id: 'leadership_goal',
          },
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'Career Growth Goal',
            },
            value: 'career_growth_goal',
            action_id: 'career_growth_goal',
          },
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'Other Goal',
            },
            value: 'other_goal',
            action_id: 'other_goal',
          },
        ],
      },
    ],
  };
};

// Slack Bot Handlers
slackApp.message(/create goal/i, async ({ message, say }) => {
  if (message.user !== process.env.SLACK_BOT_USER_ID && !message.subtype) {
    await say(askGoalDetails());
  }
});

slackApp.message(/show goals/i, async ({ message, say }) => {
  if (message.user !== process.env.SLACK_BOT_USER_ID && !message.subtype) {
    await say(showGoals(message.user));
  }
});

slackApp.message(/show sessions/i, async ({ message, say }) => {
  if (message.user !== process.env.SLACK_BOT_USER_ID && !message.subtype) {
    await say(showSessions(message.user));
  }
});

slackApp.message(/schedule session/i, async ({ message, say }) => {
  if (message.user !== process.env.SLACK_BOT_USER_ID && !message.subtype) {
    await say(searchCoaches());
  }
});

// Handle interactive button clicks
slackApp.action('leadership_goal', async ({ body, ack, say }) => {
  await ack();
  await say({
    text: 'You’ve selected a Leadership Goal. Please provide a timeframe for your goal (e.g., "3 months"):',
  });
});

slackApp.action('career_growth_goal', async ({ body, ack, say }) => {
  await ack();
  await say({
    text: 'You’ve selected a Career Growth Goal. Please provide a timeframe for your goal (e.g., "6 months"):',
  });
});

slackApp.action('other_goal', async ({ body, ack, say }) => {
  await ack();
  await say({
    text: 'Please describe your goal and provide a timeframe:',
  });
});

slackApp.action('coach_selection', async ({ body, ack, say }) => {
  await ack();
  const selectedCoach = body.actions[0].value;
  const session = {
    id: sessions.length + 1,
    coach: selectedCoach,
    date: '2025-01-30',
    user: body.user.id,
  };
  sessions.push(session);
  await say(showSessions(body.user.id));
});

// Start the Slack app
(async () => {
  try {
    await slackApp.start();
    console.log('⚡️ Slack bot is running!');
  } catch (error) {
    console.error('Error starting Slack app:', error);
  }
})();
