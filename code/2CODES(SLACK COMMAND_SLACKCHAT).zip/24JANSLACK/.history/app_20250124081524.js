require('dotenv').config();
const { App } = require('@slack/bolt');

const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET
});

slackApp.message('hello', async ({ message, say }) => {
  await say({
    text: 'Click the button!',
    blocks: [
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: { type: 'plain_text', text: 'Click Me' },
            action_id: 'sample_button',
            value: 'button_clicked'
          }
        ]
      }
    ]
  });
});

slackApp.action('sample_button', async ({ body, ack, say }) => {
  await ack();
  await say(`Button was clicked by <@${body.user.id}>!`);
});

(async () => {
  await slackApp.start(process.env.PORT || 3000);
  console.log('⚡️ Bolt app started');
})();