app.command('/mycommand', async ({ ack, respond }) => {
  try {
    console.log('Received /mycommand request');
    await ack();
    await respond({ text: 'This is the response to your command!' });
  } catch (error) {
    console.error('Error processing slash command:', error);
  }
});
