// Add the /slack/events route to handle Slack requests
app.post('/slack/events', async (req, res) => {
    // Check if req.body and req.body.type are defined
    if (req.body && req.body.type === 'url_verification') {
        return res.json({ challenge: req.body.challenge });
    }

    // Handle events passed from Slack
    if (req.body && req.body.event) {
        console.log('Slack Event:', req.body);

        const event = req.body.event;
        if (event.type === 'message' && event.text === 'search coach') {
            // Respond to the message
            const responseMessage = {
                channel: event.channel,
                text: 'Searching for a coach...'
            };

            try {
                await slackApp.client.chat.postMessage(responseMessage);
                console.log('Message sent:', responseMessage);
            } catch (error) {
                console.error('Error sending message:', error);
            }
        }
    } else {
        console.error('Invalid Slack Event:', req.body);
    }

    res.status(200).send();
});

// Start the Slack App
(async () => {
    const slackPort = process.env.SLACK_PORT || 3001;
    await slackApp.start(slackPort);
    console.log(`⚡️ Slack app is running on port ${slackPort}`);
})();

// Start the Express server for health check and event handling
const port = process.env.PORT || 3000;
app.get('/', (req, res) => res.send('Bot is running! 🚀'));
app.listen(port, () => {
    console.log(`🌐 Server is running on port ${port}`);
});