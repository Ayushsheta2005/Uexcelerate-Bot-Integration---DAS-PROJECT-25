const express = require('express');
const { App, ExpressReceiver } = require('@slack/bolt');
const bodyParser = require('body-parser');
// config env
require('dotenv').config();

// Create an ExpressReceiver
const expressReceiver = new ExpressReceiver({
  signingSecret: process.env.SLACK_SIGNING_SECRET,
  endpoints: '/slack/events'
});

// Initialize Slack app
const app = new App({
  token: process.env.SLACK_BOT_TOKEN,
  receiver: expressReceiver
});

// Create Express app
const expressApp = express();
expressApp.use(bodyParser.json());

// Slash Command: /hello
expressApp.post('/slack/hello', async (req, res) => {
  try {
    const { user_name, text } = req.body;
    res.json({
      response_type: 'in_channel',
      text: `Hello, ${user_name}! You said: ${text || 'nothing'}`
    });
  } catch (error) {
    console.error('Hello command error:', error);
    res.status(500).json({ error: 'Something went wrong' });
  }
});

// Slash Command: /weather
expressApp.post('/slack/weather', async (req, res) => {
  const location = req.body.text.trim() || 'your location';
  
  // Mock weather data
  const weatherData = {
    temperature: 72,
    condition: 'Sunny',
    humidity: 45
  };

  res.json({
    response_type: 'in_channel',
    text: `Weather for ${location}:
🌡️ Temperature: ${weatherData.temperature}°F
☀️ Condition: ${weatherData.condition}
💧 Humidity: ${weatherData.humidity}%`
  });
});

// Interactive Message Handler
app.action('lunch_selection', async ({ body, ack, respond }) => {
  await ack();
  const selection = body.actions[0].value;
  
  await respond({
    text: `Great choice! Enjoy your ${selection} 🍽️`
  });
});

// Lunch Suggestion Block Kit Message
expressApp.post('/slack/lunch', async (req, res) => {
  const lunchOptions = [
    { name: 'Pizza', emoji: '🍕' },
    { name: 'Sushi', emoji: '🍣' },
    { name: 'Salad', emoji: '🥗' },
    { name: 'Burger', emoji: '🍔' },
    { name: 'Tacos', emoji: '🌮' }
  ];

  const randomLunch = lunchOptions[Math.floor(Math.random() * lunchOptions.length)];

  res.json({
    response_type: 'in_channel',
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `How about ${randomLunch.emoji} ${randomLunch.name} for lunch today?`
        }
      },
      {
        type: 'actions',
        elements: lunchOptions.map(option => ({
          type: 'button',
          text: {
            type: 'plain_text',
            text: `${option.emoji} ${option.name}`,
            emoji: true
          },
          value: option.name,
          action_id: 'lunch_selection'
        }))
      }
    ]
  });
});

// Start server
const PORT = process.env.PORT || 3000;
expressApp.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

// Error handler
app.error(async (error) => {
  console.error('Slack app error:', error);
});