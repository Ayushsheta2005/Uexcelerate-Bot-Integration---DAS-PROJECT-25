require('dotenv').config();
const { App } = require('@slack/bolt');
const express = require('express');

// Initialize Slack Bolt app
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET
});

// Initialize Express app for handling slash command request
const expressApp = express();
expressApp.use(express.json());

// Slash Command Handler
slackApp.command('/mycommand', async ({ ack, body, respond }) => {
  await ack();  // Acknowledge the slash command request

  // Open a modal with a simple text input form
  try {
    await slackApp.client.views.open({
      trigger_id: body.trigger_id,
      view: {
        type: 'modal',
        callback_id: 'mycommand_modal',
        title: {
          type: 'plain_text',
          text: 'Enter Some Information'
        },
        blocks: [
          {
            type: 'section',
            block_id: 'input_section',
            text: {
              type: 'mrkdwn',
              text: 'Please provide some information below:'
            },
            accessory: {
              type: 'plain_text_input',
              action_id: 'input_text',
              placeholder: {
                type: 'plain_text',
                text: 'Enter something here...'
              }
            }
          }
        ]
      }
    });
  } catch (error) {
    console.error('Error opening modal:', error);
  }
});

// Modal submission handler
slackApp.view('mycommand_modal', async ({ ack, body, view, say }) => {
  await ack();  // Acknowledge the modal submission
  
  const userInput = view.state.values.input_section.input_text.value;
  console.log('User input:', userInput);  // Log the input to the console
  
  // Respond with a confirmation message
  await say(`Thank you for your input: "${userInput}"`);
});

// Start both Slack Bolt app and Express server
(async () => {
  try {
    await slackApp.start(process.env.PORT || 3000);
    console.log('⚡️ Bolt app started on Slack');
  } catch (error) {
    console.error('Error starting Slack app:', error);
  }

  const expressPort = 4000;
  expressApp.listen(expressPort, () => {
    console.log(`🌐 Express app started on http://localhost:${expressPort}`);
  });
})();
