require('dotenv').config();
const { App } = require('@slack/bolt');

// Initialize Slack App with Socket Mode
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
  socketMode: true,
  appToken: process.env.SLACK_APP_TOKEN
});

// Modules
const coaches = require('./modules/coaches');
const goals = require('./modules/goals');
const sessions = require('./modules/sessions');
const menu = require('./modules/menu');

// Main Menu Interaction
slackApp.message(/start|menu/i, async ({ message, say }) => {
  if (message.user !== process.env.SLACK_BOT_USER_ID) {
    await say(menu.generateMainMenu());
  }
});

// Comprehensive Action Handlers
const actionHandlers = {
  // Menu Navigation
  'coaches_menu': async ({ body, ack, say }) => {
    await ack();
    await say({
      text: 'Coaches Menu',
      blocks: [
        {
          type: 'section',
          text: { type: 'mrkdwn', text: '*Coaches Options* 👥' }
        },
        {
          type: 'actions',
          elements: [
            {
              type: 'button',
              text: { type: 'plain_text', text: 'View Coaches' },
              action_id: 'view_coaches_list',
              value: 'view_coaches'
            },
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Recommend Coaches' },
              action_id: 'recommend_coaches_list',
              value: 'recommend_coaches'
            }
          ]
        }
      ]
    });
  },

  'goals_menu': async ({ body, ack, say }) => {
    await ack();
    await say({
      text: 'Goals Menu',
      blocks: [
        {
          type: 'section',
          text: { type: 'mrkdwn', text: '*Goals Options* 🎯' }
        },
        {
          type: 'actions',
          elements: [
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Create Goal' },
              action_id: 'create_new_goal',
              value: 'create_goal'
            },
            {
              type: 'button',
              text: { type: 'plain_text', text: 'List Goals' },
              action_id: 'list_all_goals',
              value: 'list_goals'
            }
          ]
        }
      ]
    });
  },

  'sessions_menu': async ({ body, ack, say }) => {
    await ack();
    await say({
      text: 'Sessions Menu',
      blocks: [
        {
          type: 'section',
          text: { type: 'mrkdwn', text: '*Sessions Options* 📅' }
        },
        {
          type: 'actions',
          elements: [
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Schedule Session' },
              action_id: 'schedule_new_session',
              value: 'schedule_session'
            },
            {
              type: 'button',
              text: { type: 'plain_text', text: 'List Sessions' },
              action_id: 'list_all_sessions',
              value: 'list_sessions'
            }
          ]
        }
      ]
    });
  },

  // Coaches Actions
  'view_coaches_list': async ({ body, ack, say }) => {
    await ack();
    await say(coaches.searchCoaches());
  },

  'recommend_coaches_list': async ({ body, ack, say }) => {
    await ack();
    await say(coaches.recommendCoaches());
  },

  // Goals Actions
  'create_new_goal': async ({ body, ack, say }) => {
    await ack();
    await goals.createGoal(body, say);
  },

  'list_all_goals': async ({ body, ack, say }) => {
    await ack();
    await say(goals.listGoals());
  },

  // Sessions Actions
  'schedule_new_session': async ({ body, ack, say }) => {
    await ack();
    await sessions.scheduleSession(body, say);
  },

  'list_all_sessions': async ({ body, ack, say }) => {
    await ack();
    await say(sessions.listSessions());
  }
};

// Register all action handlers dynamically
Object.entries(actionHandlers).forEach(([actionId, handler]) => {
  slackApp.action(actionId, handler);
});

// Error Handler
slackApp.error(async (error) => {
  console.error('Slack Bot Error:', error);
});

// Start the Slack app
(async () => {
  try {
    await slackApp.start();
    console.log('⚡️ Coaching Bot is running!');
  } catch (error) {
    console.error('Error starting Slack app:', error);
  }
})();

module.exports = slackApp;