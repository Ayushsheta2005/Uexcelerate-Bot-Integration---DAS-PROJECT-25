const { App } = require('@slack/bolt');

const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET
});

const createButtonMessage = () => ({
  blocks: [
    {
      type: "actions",
      elements: [
        {
          type: "button",
          text: { type: "plain_text", text: "View Profile" },
          value: "view_profile",
          action_id: "profile_button"
        },
        {
          type: "button", 
          text: { type: "plain_text", text: "Start Project" },
          value: "start_project", 
          action_id: "project_button"
        }
      ]
    }
  ]
});

slackApp.action('profile_button', async ({ body, ack, say }) => {
  await ack();
  await say(`Profile requested by <@${body.user.id}>`);
});

slackApp.action('project_button', async ({ body, ack, say }) => {
  await ack();
  await say(`Project initiated by <@${body.user.id}>`);
});