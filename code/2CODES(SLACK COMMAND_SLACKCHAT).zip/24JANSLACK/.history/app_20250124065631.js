require('dotenv').config();
const { App } = require('@slack/bolt');
const coachesModule = require('./coaches');
const goalsModule = require('./goals');
const sessionsModule = require('./sessions');

// Initialize Slack App
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
});

// Slack Bot Handlers
slackApp.message(/create goal/i, async ({ message, say }) => {
  if (message.user !== process.env.SLACK_BOT_USER_ID && !message.subtype) {
    await say(goalsModule.showGoals());
  }
});

slackApp.message(/create action/i, async ({ message, say }) => {
  if (message.user !== process.env.SLACK_BOT_USER_ID && !message.subtype) {
    await say(goalsModule.askGoalOrAction());
  }
});

slackApp.message(/schedule session/i, async ({ message, say }) => {
  if (message.user !== process.env.SLACK_BOT_USER_ID && !message.subtype) {
    await say(coachesModule.searchCoaches());
  }
});

slackApp.message(/help/i, async ({ message, say }) => {
  if (message.user !== process.env.SLACK_BOT_USER_ID && !message.subtype) {
    await say({
      text: 'Here are some commands you can try:\n- Create Goal\n- Create Action\n- Schedule Session\n- Show Goals\n- Show Sessions',
    });
  }
});

// Handle interactive button clicks
slackApp.action('create_goal', async ({ body, ack, say }) => {
  await ack();
  await say({
    text: 'Please provide a description of your SMART goal:',
  });
});

slackApp.action('create_action', async ({ body, ack, say }) => {
  await ack();
  await say({
    text: 'Please provide a description of your coaching action:',
  });
});

slackApp.action('schedule_session', async ({ body, ack, say }) => {
  await ack();
  await say(coachesModule.coachSelectionMenu());
});

slackApp.action('coach_selection', async ({ body, ack, say }) => {
  await ack();
  const selectedCoach = body.actions[0].value;
  const session = sessionsModule.createSession(selectedCoach, body.user.id);
  await say(sessionsModule.showSessions());
});

// Start the Slack app
(async () => {
  try {
    await slackApp.start();
    console.log('⚡️ Slack bot is running!');
  } catch (error) {
    console.error('Error starting Slack app:', error);
  }
})();