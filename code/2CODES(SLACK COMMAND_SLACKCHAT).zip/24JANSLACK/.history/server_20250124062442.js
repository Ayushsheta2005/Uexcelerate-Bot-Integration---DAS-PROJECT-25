require('dotenv').config();
const express = require('express');
const { App } = require('@slack/bolt');

// Initialize the Express app
const app = express();

// Middleware to parse JSON payloads
app.use(express.json());

// Slack App Initialization
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
});

// Sample data (using some mock data for demonstration purposes)
const coaches = [
  { id: 1, name: 'Alice', expertise: 'Leadership', availability: 'Weekdays', rating: 4.5, location: 'New York', languages: ['English', 'Spanish'] },
  { id: 2, name: 'Bob', expertise: 'Career Growth', availability: 'Weekends', rating: 4.7, location: 'London', languages: ['English', 'French'] },
  // more coaches
];
const goals = [];
const actions = [];
const sessions = [];

// Shared functions for beautiful formatting
const searchCoaches = () => {
  return {
    blocks: [
      {
        type: 'section',
        block_id: 'coaches_list',
        text: {
          type: 'mrkdwn',
          text: '*Available Coaches*:\nHere are some great coaches you can choose from:',
        },
      },
      ...coaches.map(coach => ({
        type: 'section',
        fields: [
          { type: 'mrkdwn', text: `*Name:* ${coach.name}` },
          { type: 'mrkdwn', text: `*Expertise:* ${coach.expertise}` },
          { type: 'mrkdwn', text: `*Rating:* ${coach.rating}` },
          { type: 'mrkdwn', text: `*Availability:* ${coach.availability}` },
          { type: 'mrkdwn', text: `*Location:* ${coach.location}` },
          { type: 'mrkdwn', text: `*Languages:* ${coach.languages.join(', ')}` },
        ],
      })),
      {
        type: 'divider',
      },
    ],
  };
};

// Function to ask for action or goal type
const askGoalOrAction = () => {
  return {
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: 'What would you like to do? Choose one of the options below:',
        },
      },
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'Create Goal',
            },
            value: 'create_goal',
            action_id: 'create_goal',
          },
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'Create Action',
            },
            value: 'create_action',
            action_id: 'create_action',
          },
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'Schedule Session with Coach',
            },
            value: 'schedule_session',
            action_id: 'schedule_session',
          },
        ],
      },
    ],
  };
};

// Function to schedule session with a coach
const scheduleSession = (userId) => {
  const id = sessions.length + 1;
  const session = { id, coach: 'Alice', date: '2025-01-30', user: userId };
  sessions.push(session);

  return {
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*Session Scheduled Successfully* 📅\nCoach: *${session.coach}*\nDate: *${session.date}*`,
        },
      },
      {
        type: 'divider',
      },
    ],
  };
};

// Slack Bot Handlers
slackApp.message(/create goal/i, async ({ message, say }) => {
    if(message.user!=process.env.SLACK_BOT_TOKEN)
  await say(askGoalOrAction());
});

slackApp.message(/create action/i, async ({ message, say }) => {
    if(message.user!=process.env.SLACK_BOT_TOKEN)
  await say(askGoalOrAction());
});

slackApp.message(/help/i, async ({ message, say }) => {
    if(message.user!=process.env.SLACK_BOT_TOKEN)
  await say(helpMessage());
});

// Handle interactive button clicks
slackApp.action('create_goal', async ({ body, ack, say }) => {
    if(message.user!=process.env.SLACK_BOT_TOKEN)
  await ack();
  await say({
    text: 'Please provide a description of your SMART goal:',
    // Add an input field for goal description (or a modal for better user experience)
  });
});

slackApp.action('create_action', async ({ body, ack, say }) => {
  await ack();
  await say({
    text: 'Please provide a description of your coaching action:',
    // Add an input field for action description
  });
});

slackApp.action('schedule_session', async ({ body, ack, say }) => {
  await ack();
  await say({
    text: 'Which coach would you like to schedule a session with?',
    attachments: [
      {
        text: 'Choose a coach from the list below:',
        callback_id: 'coach_selection',
        actions: coaches.map(coach => ({
          name: 'coach',
          text: coach.name,
          type: 'button',
          value: coach.name,
        })),
      },
    ],
  });
});

// Add the /slack/events route to handle Slack requests
app.post('/slack/events', async (req, res) => {
  try {
    if (req.body && req.body.type === 'url_verification') {
      return res.json({ challenge: req.body.challenge });
    }

    if (req.body && req.body.event) {
      const { event } = req.body;
      console.log('Slack Event:', event);

      if (event.type === 'message' && event.text) {
        // Bot command handling
        const text = event.text.toLowerCase();

        if (text.includes('create goal') || text.includes('create action')) {
          await slackApp.client.chat.postMessage({
            channel: event.channel,
            blocks: askGoalOrAction().blocks,
          });
        }
      }
    }
    res.status(200).send();
  } catch (error) {
    console.error('Error handling Slack event:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Start the Slack App
(async () => {
  try {
    const slackPort = process.env.SLACK_PORT || 3001;
    await slackApp.start(slackPort);
    console.log(`⚡️ Slack app is running on port ${slackPort}`);
  } catch (error) {
    console.error('Error starting Slack app:', error);
  }
})();

// Start the Express server for health check and event handling
const port = process.env.PORT || 3000;
app.get('/', (req, res) => res.send('Bot is running! 🚀'));
app.listen(port, () => {
  console.log(`🌐 Server is running on port ${port}`);
});
