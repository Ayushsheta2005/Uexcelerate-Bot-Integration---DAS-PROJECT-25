require('dotenv').config();
const { App } = require('@slack/bolt');
const express = require('express');

// Initialize Express app
const appExpress = express();

// Initialize the Slack app with Slack tokens
const app = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
});

// Sample data
const coaches = [
  { id: 1, name: 'Coach Alice', expertise: 'Leadership', availability: 'Weekdays', rating: 4.5 },
  { id: 2, name: 'Coach Bob', expertise: 'Career Growth', availability: 'Weekends', rating: 4.7 },
  { id: 3, name: 'Coach Carol', expertise: 'Communication', availability: 'Weekdays', rating: 4.9 },
];

const goals = [];
const actions = [];
const sessions = [];

// Slash command for initiating the bot
app.command('/coachbot', async ({ command, ack, say }) => {
  await ack(); // Acknowledge the command immediately
  await say(`Welcome to CoachBot! You can perform the following actions:
1️⃣ Search for a Coach
2️⃣ Create an Action
3️⃣ Create a Goal
4️⃣ Schedule a Coaching Session
Type "help" for details!`);
});

// Listener for coach search
app.message(/search coach/i, async ({ message, say, ack }) => {
  await ack(); // Acknowledge the message immediately
  let result = 'Available Coaches:\n';
  coaches.forEach((coach) => {
    result += `👤 ${coach.name} | Expertise: ${coach.expertise} | Availability: ${coach.availability} | Rating: ${coach.rating}\n`;
  });
  await say(result);
});

// Listener for creating an action
app.message(/create action/i, async ({ message, say, ack }) => {
  await ack(); // Acknowledge the message immediately
  const actionId = actions.length + 1;
  const sampleAction = { id: actionId, description: 'Sample action', owner: message.user };
  actions.push(sampleAction);
  await say(`Action created successfully! 🎯\nDetails: ID ${actionId}, Description: ${sampleAction.description}`);
});

// Listener for creating a goal
app.message(/create goal/i, async ({ message, say, ack }) => {
  await ack(); // Acknowledge the message immediately
  const goalId = goals.length + 1;
  const sampleGoal = { id: goalId, description: 'SMART goal', owner: message.user };
  goals.push(sampleGoal);
  await say(`Goal created successfully! 🥅\nDetails: ID ${goalId}, Description: ${sampleGoal.description}`);
});

// Listener for scheduling a session
app.message(/schedule session/i, async ({ message, say, ack }) => {
  await ack(); // Acknowledge the message immediately
  const sessionId = sessions.length + 1;
  const sampleSession = { id: sessionId, coach: 'Coach Alice', date: '2025-01-30', user: message.user };
  sessions.push(sampleSession);
  await say(`Session scheduled successfully! 📅\nCoach: ${sampleSession.coach}, Date: ${sampleSession.date}`);
});

// Listener for help
app.message(/help/i, async ({ message, say, ack }) => {
  await ack(); // Acknowledge the message immediately
  await say(`Here are the commands you can use:
- "search coach": View all available coaches.
- "create action": Create a coaching action.
- "create goal": Set a SMART goal.
- "schedule session": Schedule a new coaching session.`);
});

// Notification for reminders (simulated)
app.message(/reminder/i, async ({ message, say, ack }) => {
  await ack(); // Acknowledge the message immediately
  await say(`🔔 Reminder: Don't forget to follow up on your coaching goals and actions!`);
});

// Add an express route for the root
appExpress.get('/', (req, res) => {
  res.send('⚡️ Slack Bot is running!');
});

// Attach Bolt to Express using the correct receiver
appExpress.use('/slack/events', app.receiver.router);

// Start the app
(async () => {
  const port = process.env.PORT || 3000;
  await app.start(); // Start Bolt's internal listener
  appExpress.listen(port, () => {
    console.log(`⚡️ Slack Bot is running on http://localhost:${port}`);
  });
})();
