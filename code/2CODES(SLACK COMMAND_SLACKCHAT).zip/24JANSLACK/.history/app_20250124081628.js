require('dotenv').config();
const { App } = require('@slack/bolt');

const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
  socketMode: true,
  appToken: process.env.SLACK_APP_TOKEN
});

slackApp.message('hello', async ({ message, say }) => {
  console.log('Hello message received:', message);
  await say({
    text: 'Click the button!',
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: 'Press the button below:'
        }
      },
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: { 
              type: 'plain_text', 
              text: 'Click Me',
              emoji: true
            },
            action_id: 'sample_button',
            value: 'button_clicked'
          }
        ]
      }
    ]
  });
});

slackApp.action('sample_button', async ({ body, ack, say }) => {
  console.log('Button click received:', body);
  try {
    await ack();
    await say({
      text: `Button was clicked by <@${body.user.id}>!`,
      blocks: [
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: `Button was clicked by <@${body.user.id}>!`
          }
        }
      ]
    });
  } catch (error) {
    console.error('Error handling button click:', error);
  }
});

// Global error handler
slackApp.error(async (error) => {
  console.error('Slack App Error:', error);
});

// Start the app
(async () => {
  try {
    await slackApp.start(process.env.PORT || 3000);
    console.log('⚡️ Bolt app started');
  } catch (error) {
    console.error('App start error:', error);
  }
})();