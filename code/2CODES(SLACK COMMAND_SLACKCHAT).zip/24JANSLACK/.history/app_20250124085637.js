require('dotenv').config();
const { App } = require('@slack/bolt');

// Initialize the Slack app
const app = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
});

// Slash Command handler
app.command('/mycommand', async ({ ack, respond }) => {
  // Acknowledge the command request
  await ack();

  // Respond with a message
  await respond({
    text: 'Hello, this is a response to your slash command!',
  });
});



// Start the app
(async () => {
  try {
    await app.start(process.env.PORT || 3000);
    console.log('⚡️ Slack app started');
  } catch (error) {
    console.error('Error starting Slack app:', error);
  }
})();
