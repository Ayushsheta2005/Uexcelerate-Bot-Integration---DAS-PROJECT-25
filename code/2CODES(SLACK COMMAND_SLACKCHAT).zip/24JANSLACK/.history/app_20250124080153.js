require('dotenv').config();
const { App } = require('@slack/bolt');
const winston = require('winston');

// Configure Logging
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console({
      format: winston.format.simple()
    }),
    new winston.transports.File({ 
      filename: 'error.log', 
      level: 'error' 
    }),
    new winston.transports.File({ 
      filename: 'combined.log' 
    })
  ]
});

// Import Modules
const { 
  searchCoaches, 
  getCoachDetails, 
  recommendCoaches 
} = require('./modules/coaches');
const { 
  createGoal, 
  listGoals, 
  updateGoal, 
  deleteGoal 
} = require('./modules/goals');
const { 
  scheduleSession, 
  listSessions 
} = require('./modules/schedules');
const { 
  generateMainMenu,
  handleMainMenuSelection 
} = require('./modules/menu');

// Safe Action Handler
const safeActionHandler = (actionName, handler) => {
  return async (params) => {
    const { body, ack, say } = params;
    try {
      logger.info(`Handling action: ${actionName}`, { 
        actionDetails: body.actions?.[0] 
      });

      await ack();
      await handler(params);
    } catch (error) {
      logger.error(`Error in ${actionName} action`, {
        error: error.message,
        stack: error.stack,
        actionBody: JSON.stringify(body)
      });
      
      try {
        await say({
          text: `❌ An error occurred while processing your request.`,
          blocks: [
            {
              type: 'section',
              text: { 
                type: 'mrkdwn', 
                text: `*Error in ${actionName}*\nPlease contact support.` 
              }
            }
          ]
        });
      } catch (notificationError) {
        logger.error('Failed to send error notification', notificationError);
      }
    }
  };
};

// Initialize Slack App
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
  socketMode: true,
  appToken: process.env.SLACK_APP_TOKEN,
  logger: {
    debug: (...msgs) => logger.debug(msgs),
    info: (...msgs) => logger.info(msgs),
    warn: (...msgs) => logger.warn(msgs),
    error: (...msgs) => logger.error(msgs)
  }
});

// Action Handlers
const actionHandlers = {
  'main_menu_selection': async ({ body, say }) => {
    const selection = body.actions[0].value;
    await handleMainMenuSelection(selection, say);
  },
  'view_coaches': async ({ say }) => {
    await say(searchCoaches());
  },
  'recommend_coaches': async ({ say }) => {
    await say(recommendCoaches());
  },
  'coach_details': async ({ body, say }) => {
    const coachId = body.actions[0].value;
    await say(getCoachDetails(coachId));
  },
  'create_goal': async ({ say }) => {
    await createGoal(say);
  },
  'list_goals': async ({ say }) => {
    await say(listGoals());
  },
  'update_goal': async ({ say }) => {
    await updateGoal(say);
  },
  'delete_goal': async ({ say }) => {
    await deleteGoal(say);
  },
  'schedule_session': async ({ say }) => {
    await scheduleSession(say);
  },
  'list_sessions': async ({ say }) => {
    await say(listSessions());
  }
};

// Main Menu Interaction
slackApp.message(/start|menu/i, async ({ message, say }) => {
  try {
    logger.info(`Main menu triggered by message: ${message.text}`);
    await say(generateMainMenu());
  } catch (error) {
    logger.error('Error in main menu interaction', error);
  }
});

// Register Safe Action Handlers
Object.entries(actionHandlers).forEach(([actionId, handler]) => {
  slackApp.action(actionId, safeActionHandler(actionId, handler));
});

// Advanced Error Handler
slackApp.error(async (error) => {
  logger.error('Unhandled Slack App Error', {
    message: error.message,
    stack: error.stack
  });
});

// Graceful Startup
(async () => {
  try {
    await slackApp.start();
    logger.info('🚀 Coaching Bot successfully launched');
    
    // Periodic Health Check
    setInterval(() => {
      logger.info('Periodic health check completed');
    }, 30 * 60 * 1000);
  } catch (startupError) {
    logger.error('❌ Failed to start Slack Bot', startupError);
    process.exit(1);
  }
})();

module.exports = slackApp;