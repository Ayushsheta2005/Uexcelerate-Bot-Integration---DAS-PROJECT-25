const coaches = [
    {
      id: '1',
      name: 'Alice Thompson',
      expertise: ['Leadership', 'Career Development'],
      rating: 4.8,
      languages: ['English', 'Spanish'],
      availability: 'Weekdays',
      bio: 'Former Fortune 500 executive with 15 years of leadership coaching experience.',
      specialties: ['Tech Leadership', 'Women in Management']
    },
    {
      id: '2',
      name: 'Bob Rodriguez',
      expertise: ['Career Growth', 'Communication Skills'],
      rating: 4.7,
      languages: ['English', 'Portuguese'],
      availability: 'Weekends',
      bio: 'International communication expert and career transition specialist.',
      specialties: ['Startup Mentoring', 'Intercultural Communication']
    }
  ];
  
  module.exports = {
    searchCoaches: () => ({
      blocks: [
        {
          type: 'section',
          text: { type: 'mrkdwn', text: '*Available Coaches* 👥' }
        },
        ...coaches.map(coach => ({
          type: 'section',
          text: { 
            type: 'mrkdwn', 
            text: `*${coach.name}* (Rating: ${coach.rating}/5)\n_Expertise:_ ${coach.expertise.join(', ')}` 
          },
          accessory: {
            type: 'button',
            text: { type: 'plain_text', text: 'View Details' },
            value: coach.id,
            action_id: 'coach_details'
          }
        }))
      ]
    }),
  
    getCoachDetails: (coachId) => {
      const coach = coaches.find(c => c.id === coachId);
      return coach ? {
        blocks: [
          {
            type: 'section',
            text: { 
              type: 'mrkdwn', 
              text: `*${coach.name}* 🌟\n\n*Bio:* ${coach.bio}\n\n*Expertise:* ${coach.expertise.join(', ')}\n*Languages:* ${coach.languages.join(', ')}\n*Rating:* ${coach.rating}/5\n*Specialties:* ${coach.specialties.join(', ')}` 
            }
          }
        ]
      } : { text: 'Coach not found' };
    },
  
    recommendCoaches: () => {
      const topCoaches = coaches
        .filter(coach => coach.rating >= 4.7)
        .slice(0, 2);
  
      return {
        blocks: [
          {
            type: 'section',
            text: { type: 'mrkdwn', text: '*Recommended Coaches* 🌈' }
          },
          ...topCoaches.map(coach => ({
            type: 'section',
            text: { 
              type: 'mrkdwn', 
              text: `*${coach.name}* (Rating: ${coach.rating}/5)\n_Top Specialties:_ ${coach.specialties.join(', ')}` 
            },
            accessory: {
              type: 'button',
              text: { type: 'plain_text', text: 'View Details' },
              value: coach.id,
              action_id: 'coach_details'
            }
          }))
        ]
      };
    }
  };