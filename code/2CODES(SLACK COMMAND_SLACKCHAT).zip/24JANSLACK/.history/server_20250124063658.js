const { App } = require('@slack/bolt');

// Initialize the Slack app
const app = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET
});

// Listen for messages that contain "hello"
app.message(/hello/i, async ({ message, say }) => {
  // Respond with "hello" if the message contains "hello"
  await say('hello');
});

// Start the app
(async () => {
  await app.start();
  console.log('Slack bot is running!');
})();
