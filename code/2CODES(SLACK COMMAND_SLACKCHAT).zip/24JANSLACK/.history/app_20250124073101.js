/ /app.js

require('dotenv').config();
const { App } = require('@slack/bolt');
const { 
  searchCoaches, 
  getCoachDetails, 
  recommendCoaches 
} = require('./modules/coaches');
const { 
  createGoal, 
  listGoals, 
  updateGoal, 
  deleteGoal 
} = require('./modules/goals');
const { 
  scheduleSession, 
  listSessions, 
  cancelSession 
} = require('./modules/schedules');
const { 
  generateMainMenu,
  handleMainMenuSelection 
} = require('./modules/menu.js');

// Initialize Slack App
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
});

// Main Menu Interaction
slackApp.message(/start|menu/i, async ({ message, say }) => {

    await say(generateMainMenu());

});

// Main Menu Action Handler
slackApp.action('main_menu_selection', async ({ body, ack, say }) => {
  await ack();
  await handleMainMenuSelection(body, say);
});

// Coaches Interactions
slackApp.action('view_coaches', async ({ body, ack, say }) => {
  await ack();
  await say(searchCoaches());
});

slackApp.action('recommend_coaches', async ({ body, ack, say }) => {
  await ack();
  await say(recommendCoaches());
});

slackApp.action('coach_details', async ({ body, ack, say }) => {
  await ack();
  const coachId = body.actions[0].value;
  await say(getCoachDetails(coachId));
});

// Goals Interactions
slackApp.action('create_goal', async ({ body, ack, say }) => {
  await ack();
  await createGoal(body, say);
});

slackApp.action('list_goals', async ({ body, ack, say }) => {
  await ack();
  await say(listGoals());
});

slackApp.action('update_goal', async ({ body, ack, say }) => {
  await ack();
  await updateGoal(body, say);
});

slackApp.action('delete_goal', async ({ body, ack, say }) => {
  await ack();
  await deleteGoal(body, say);
});

// Sessions Interactions
slackApp.action('schedule_session', async ({ body, ack, say }) => {
  await ack();
  await scheduleSession(body, say);
});

slackApp.action('list_sessions', async ({ body, ack, say }) => {
  await ack();
  await say(listSessions());
});

slackApp.action('cancel_session', async ({ body, ack, say }) => {
  await ack();
  await cancelSession(body, say);
});

// Error Handler
slackApp.error(async (error) => {
  console.error('Slack Bot Error:', error);
});

// Start the Slack app
(async () => {
  try {
    await slackApp.start();
    console.log('⚡️ Coaching Bot is running!');
  } catch (error) {
    console.error('Error starting Slack app:', error);
  }
})();

fix code , button presss nothing happens on temrinal it says
[INFO]   Unhandled HTTP request (POST) made to /slack/actions
[INFO]   Unhandled HTTP request (POST) made to /slack/actions
[INFO]   Unhandled HTTP request (POST) made to /slack/actions
[INFO]   Unhandled HTTP request (POST) made to /slack/actions
[nodemon] restarting due to changes...

here are the modules

const coaches = [
    {
      id: '1',
      name: 'Alice Thompson',
      expertise: ['Leadership', 'Career Development'],
      rating: 4.8,
      languages: ['English', 'Spanish'],
      availability: 'Weekdays',
      bio: 'Former Fortune 500 executive with 15 years of leadership coaching experience.',
      specialties: ['Tech Leadership', 'Women in Management']
    },
    {
      id: '2',
      name: 'Bob Rodriguez',
      expertise: ['Career Growth', 'Communication Skills'],
      rating: 4.7,
      languages: ['English', 'Portuguese'],
      availability: 'Weekends',
      bio: 'International communication expert and career transition specialist.',
      specialties: ['Startup Mentoring', 'Intercultural Communication']
    }
  ];

  module.exports = {
    searchCoaches: () => ({
      blocks: [
        {
          type: 'section',
          text: { type: 'mrkdwn', text: 'Available Coaches 👥' }
        },
        ...coaches.map(coach => ({
          type: 'section',
          text: { 
            type: 'mrkdwn', 
            text: *${coach.name}* (Rating: ${coach.rating}/5)\n_Expertise:_ ${coach.expertise.join(', ')} 
          },
          accessory: {
            type: 'button',
            text: { type: 'plain_text', text: 'View Details' },
            value: coach.id,
            action_id: 'coach_details'
          }
        }))
      ]
    }),

    getCoachDetails: (coachId) => {
      const coach = coaches.find(c => c.id === coachId);
      return coach ? {
        blocks: [
          {
            type: 'section',
            text: { 
              type: 'mrkdwn', 
              text: *${coach.name}* 🌟\n\n*Bio:* ${coach.bio}\n\n*Expertise:* ${coach.expertise.join(', ')}\n*Languages:* ${coach.languages.join(', ')}\n*Rating:* ${coach.rating}/5\n*Specialties:* ${coach.specialties.join(', ')} 
            }
          }
        ]
      } : { text: 'Coach not found' };
    },

    recommendCoaches: () => {
      const topCoaches = coaches
        .filter(coach => coach.rating >= 4.7)
        .slice(0, 2);

      return {
        blocks: [
          {
            type: 'section',
            text: { type: 'mrkdwn', text: 'Recommended Coaches 🌈' }
          },
          ...topCoaches.map(coach => ({
            type: 'section',
            text: { 
              type: 'mrkdwn', 
              text: *${coach.name}* (Rating: ${coach.rating}/5)\n_Top Specialties:_ ${coach.specialties.join(', ')} 
            },
            accessory: {
              type: 'button',
              text: { type: 'plain_text', text: 'View Details' },
              value: coach.id,
              action_id: 'coach_details'
            }
          }))
        ]
      };
    }
  };
const goals = [];

module.exports = {
  createGoal: async (body, say) => {
    await say({
      blocks: [
        {
          type: 'section',
          text: { 
            type: 'mrkdwn', 
            text: 'Create a SMART Goal 🎯\n\nPlease provide:\n• Specific objective\n• Measurable outcome\n• Achievable target\n• Relevant purpose\n• Time-bound deadline' 
          }
        },
        {
          type: 'actions',
          elements: [
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Cancel' },
              value: 'cancel_goal_creation',
              action_id: 'cancel_goal'
            }
          ]
        }
      ]
    });
  },

  listGoals: () => ({
    blocks: [
      {
        type: 'section',
        text: { type: 'mrkdwn', text: 'Your Goals 🏆' }
      },
      ...(goals.length > 0 
        ? goals.map((goal, index) => ({
            type: 'section',
            text: { 
              type: 'mrkdwn', 
              text: *Goal ${index + 1}:* ${goal.title}\n_Status:_ ${goal.status}\n*Deadline:* ${goal.deadline} 
            },
            accessory: {
              type: 'button',
              text: { type: 'plain_text', text: 'Update' },
              value: update_goal_${index},
              action_id: 'update_goal'
            }
          }))
        : [{
            type: 'section',
            text: { type: 'mrkdwn', text: 'No goals created yet. Start by setting your first goal!' }
          }]
      )
    ]
  }),

  updateGoal: async (body, say) => {
    await say({
      blocks: [
        {
          type: 'section',
          text: { 
            type: 'mrkdwn', 
            text: 'Update Goal 🔧\n\nChoose what you want to modify:' 
          }
        },
        {
          type: 'actions',
          elements: [
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Title' },
              value: 'update_goal_title',
              action_id: 'update_goal_title'
            },
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Status' },
              value: 'update_goal_status',
              action_id: 'update_goal_status'
            },
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Deadline' },
              value: 'update_goal_deadline',
              action_id: 'update_goal_deadline'
            }
          ]
        }
      ]
    });
  },

  deleteGoal: async (body, say) => {
    await say({
      blocks: [
        {
          type: 'section',
          text: { 
            type: 'mrkdwn', 
            text: 'Delete Goal 🗑️\n\nAre you sure you want to delete this goal?' 
          }
        },
        {
          type: 'actions',
          elements: [
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Confirm Delete' },
              style: 'danger',
              value: 'confirm_goal_deletion',
              action_id: 'confirm_goal_deletion'
            },
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Cancel' },
              value: 'cancel_goal_deletion',
              action_id: 'cancel_goal_deletion'
            }
          ]
        }
      ]
    });
  }
