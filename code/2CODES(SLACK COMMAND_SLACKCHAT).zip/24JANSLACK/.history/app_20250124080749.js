require('dotenv').config();
const { App } = require('@slack/bolt');

// Initialize Slack App
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
  socketMode: true,
  appToken: process.env.SLACK_APP_TOKEN
});

// Function to create interactive buttons
const createInteractiveMessage = () => {
  return {
    text: "Choose an action:",
    blocks: [
      {
        type: "section",
        text: {
          type: "mrkdwn",
          text: "Select an option:"
        }
      },
      {
        type: "actions",
        elements: [
          {
            type: "button",
            text: {
              type: "plain_text",
              text: "View Profile",
              emoji: true
            },
            value: "view_profile",
            action_id: "profile_button"
          },
          {
            type: "button",
            text: {
              type: "plain_text",
              text: "Start Project",
              emoji: true
            },
            value: "start_project",
            action_id: "project_button"
          },
          {
            type: "button",
            text: {
              type: "plain_text",
              text: "Request Help",
              emoji: true
            },
            value: "request_help",
            action_id: "help_button"
          }
        ]
      }
    ]
  };
};

// Trigger button message command
slackApp.command('/buttons', async ({ ack, respond }) => {
  await ack();
  await respond(createInteractiveMessage());
});

// Button interaction handlers
slackApp.action('profile_button', async ({ body, ack, say }) => {
  await ack();
  await say(`Profile requested by <@${body.user.id}>`);
});

slackApp.action('project_button', async ({ body, ack, say }) => {
  await ack();
  await say(`New project initiated by <@${body.user.id}>`);
});

slackApp.action('help_button', async ({ body, ack, say }) => {
  await ack();
  await say(`Help requested by <@${body.user.id}>`);
});

// Error handler
slackApp.error(async (error) => {
  console.error('Slack Bot Error:', error);
});

// Start the app
(async () => {
  try {
    await slackApp.start();
    console.log('⚡️ Slack Bot is running!');
  } catch (error) {
    console.error('Error starting app:', error);
  }
})();