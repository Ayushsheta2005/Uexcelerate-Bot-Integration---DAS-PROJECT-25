const { App } = require('@slack/bolt');

// Initialize the Slack app with bot token and signing secret
const app = new App({
  token: xoxb-8269329162614-8335555288038-agjQU5VI9ZYJDzB2wErFgwci,  // Make sure this is set correctly
  signingSecret: 
});

// Listen for messages that contain "hello"
app.message(/hello/i, async ({ message, say }) => {
  // Respond with "hello" if the message contains "hello"
  await say('hello');
});

// Start the app
(async () => {
  await app.start();
  console.log('Slack bot is running!');
})();
