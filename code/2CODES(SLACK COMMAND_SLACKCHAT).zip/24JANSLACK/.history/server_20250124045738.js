require('dotenv').config();
const express = require('express');
const { App } = require('@slack/bolt');
const { BotFrameworkAdapter } = require('botbuilder');

// Initialize the Express app
const app = express();

// Slack App Initialization
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
});


// Sample data
const coaches = [
  { id: 1, name: 'Alice', expertise: 'Leadership', availability: 'Weekdays', rating: 4.5 },
  { id: 2, name: 'Bob', expertise: 'Career Growth', availability: 'Weekends', rating: 4.7 },
];
const goals = [];
const actions = [];
const sessions = [];

// Shared functions
const searchCoaches = () => {
  return coaches.map(
    (coach) => `👤 ${coach.name} | Expertise: ${coach.expertise} | Availability: ${coach.availability} | Rating: ${coach.rating}`
  ).join('\n');
};

const createAction = (userId) => {
  const id = actions.length + 1;
  const action = { id, description: 'New Action', owner: userId };
  actions.push(action);
  return `Action created successfully! 🎯\nDetails: ID ${id}, Description: ${action.description}`;
};

const createGoal = (userId) => {
  const id = goals.length + 1;
  const goal = { id, description: 'SMART Goal', owner: userId };
  goals.push(goal);
  return `Goal created successfully! 🥅\nDetails: ID ${id}, Description: ${goal.description}`;
};

const scheduleSession = (userId) => {
  const id = sessions.length + 1;
  const session = { id, coach: 'Alice', date: '2025-01-30', user: userId };
  sessions.push(session);
  return `Session scheduled successfully! 📅\nCoach: ${session.coach}, Date: ${session.date}`;
};

// Slack Bot Handlers
slackApp.message(/search coach/i, async ({ say }) => {
  await say(searchCoaches());
});

slackApp.message(/create action/i, async ({ message, say }) => {
  await say(createAction(message.user));
});

slackApp.message(/create goal/i, async ({ message, say }) => {
  await say(createGoal(message.user));
});

slackApp.message(/schedule session/i, async ({ message, say }) => {
  await say(scheduleSession(message.user));
});

slackApp.message(/help/i, async ({ say }) => {
  await say(`Here are the commands you can use:
- "search coach": View all available coaches.
- "create action": Create a coaching action.
- "create goal": Set a SMART goal.
- "schedule session": Schedule a new coaching session.`);
});


// Start the Slack App
(async () => {
  const slackPort = process.env.SLACK_PORT || 3001;
  await slackApp.start(slackPort);
  console.log(`⚡️ Slack app is running on port ${slackPort}`);
})();

// Start the Express server for Teams and health check
const port = process.env.PORT || 3000;
app.get('/', (req, res) => res.send('Bot is running! 🚀'));
app.listen(port, () => {
  console.log(`🌐 Server is running on port ${port}`);
});
