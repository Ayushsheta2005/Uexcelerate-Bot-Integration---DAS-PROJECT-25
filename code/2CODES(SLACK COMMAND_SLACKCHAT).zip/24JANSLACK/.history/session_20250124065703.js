// Array to store scheduled sessions
const sessions = [];

// Function to return a list of scheduled sessions
const showSessions = () => {
  return {
    blocks: [
      {
        type: 'section',
        block_id: 'sessions_list',
        text: {
          type: 'mrkdwn',
          text: '*Scheduled Sessions*:\nHere are the sessions that have been scheduled:',
        },
      },
      ...sessions.map(session => ({
        type: 'section',
        fields: [
          { type: 'mrkdwn', text: `*Coach:* ${session.coach}` },
          { type: 'mrkdwn', text: `*Date:* ${session.date}` },
        ],
      })),
      {
        type: 'divider',
      },
    ],
  };
};

// Function to create a new session
const createSession = (coachName, userId) => {
  const session = {
    id: sessions.length + 1,
    coach: coachName,
    date: '2025-01-30',
    user: userId,
  };
  sessions.push(session);
  return session;
};

module.exports = {
  sessions,
  showSessions,
  createSession,
};