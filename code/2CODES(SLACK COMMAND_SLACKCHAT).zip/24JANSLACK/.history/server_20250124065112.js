require('dotenv').config();
const { App } = require('@slack/bolt');
const express = require('express');

// Initialize Slack App with bot token and signing secret
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
});

// Initialize Express app
const app = express();

// Middleware to parse incoming JSON requests
app.use(express.json());

// Sample mock data for coaches
const coaches = [
  { id: 1, name: 'Alice', expertise: 'Leadership' },
  { id: 2, name: 'Bob', expertise: 'Career Growth' },
  { id: 3, name: 'Charlie', expertise: 'Motivation' },
];

let sessions = [];

// Function to create and display available coaches
const displayCoaches = () => {
  return {
    blocks: [
      {
        type: 'section',
        block_id: 'coaches_list',
        text: {
          type: 'mrkdwn',
          text: '*Available Coaches*:\nPlease select a coach to schedule a session:',
        },
      },
      {
        type: 'actions',
        elements: coaches.map(coach => ({
          type: 'button',
          text: {
            type: 'plain_text',
            text: coach.name,
          },
          value: coach.name,  // Use the coach's name as the value
          action_id: 'select_coach',  // This is the unique action ID
        })),
      },
    ],
  };
};

// Function to handle scheduling a session
const scheduleSession = (userId, coachName) => {
  const session = {
    id: sessions.length + 1,
    coach: coachName,
    date: '2025-02-01',  // Hardcoded date for simplicity
    user: userId,
  };
  sessions.push(session);

  return {
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*Session Scheduled Successfully* 📅\nCoach: *${coachName}*\nDate: *2025-02-01*`,
        },
      },
      {
        type: 'divider',
      },
    ],
  };
};

// Handle user requests for available coaches and session scheduling
slackApp.message(/schedule session/i, async ({ message, say }) => {
  if (message.user !== process.env.SLACK_BOT_USER_ID && !message.subtype) {
    // Display available coaches when user requests to schedule a session
    await say(displayCoaches());
  }
});

// Handle button click actions (when a coach is selected)
slackApp.action('select_coach', async ({ body, ack, say }) => {
  await ack(); // Acknowledge the interaction

  const selectedCoach = body.actions[0].value;  // Get the selected coach name
  const userId = body.user.id;  // Get the user ID of the person who clicked the button

  // Schedule a session with the selected coach
  const sessionMessage = scheduleSession(userId, selectedCoach);

  // Respond with the session confirmation message
  await say(sessionMessage);
});

// Add the route to handle Slack events (like button interactions)
app.post('/slack/actions', async (req, res) => {
  try {
    const { type, challenge, event } = req.body;
    
    // Respond to Slack URL verification challenge
    if (type === 'url_verification') {
      return res.json({ challenge });
    }

    if (event && event.type === 'message' && event.text) {
      const text = event.text.toLowerCase();
      
      if (text.includes('schedule session')) {
        // If the user asks to schedule a session, send the list of coaches
        await slackApp.client.chat.postMessage({
          channel: event.channel,
          blocks: displayCoaches().blocks,
        });
      }
    }

    res.status(200).send();
  } catch (error) {
    console.error('Error handling Slack event:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Start the Slack app
(async () => {
  try {
    const slackPort = process.env.SLACK_PORT || 3001;
    await slackApp.start(slackPort);
    console.log(`⚡️ Slack app is running on port ${slackPort}`);
  } catch (error) {
    console.error('Error starting Slack app:', error);
  }
})();

// Start the Express server
const port = process.env.PORT || 3000;
app.get('/', (req, res) => res.send('Bot is running! 🚀'));
app.listen(port, () => {
  console.log(`🌐 Server is running on port ${port}`);
});
