require('dotenv').config();
const { App } = require('@slack/bolt');
const express = require('express');
const fetch = require('node-fetch');  // Ensure fetch is imported for making requests

// Initialize Slack Bolt app
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET
});

// Initialize Express app
const expressApp = express();
expressApp.use(express.json());

// Define the Slack message listener for "hello"
slackApp.message('hello', async ({ message, say }) => {
  console.log('Received "hello" message in Slack'); // Debugging: Track message reception

  try {
    await say({
      text: 'Click the button!',
      blocks: [
        {
          type: 'actions',
          elements: [
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Click Me' },
              action_id: 'sample_button',
              value: 'button_clicked'
            }
          ]
        }
      ]
    });
    console.log('Sent button to Slack'); // Debugging: Track if message is sent
  } catch (error) {
    console.error('Error sending message to Slack:', error);
  }
});

// Define action listener for the button click
slackApp.action('sample_button', async ({ body, ack, say }) => {
  console.log('Button clicked by user:', body.user.id); // Debugging: Track button click
  

  try {
    await ack();
    await say(`Button was clicked by <@${body.user.id}>!`);
    
    // Notify an external service (example usage of the third route)
    const userId = body.user.id;
    console.log('Sending notification to external service'); // Debugging: Track notification sending

    const response = await fetch(`http://localhost:4000/notify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, event: 'button_clicked' })
    });

    if (!response.ok) {
      console.error('Failed to send notification to external service:', response.statusText);
    } else {
      console.log('Notification sent to external service successfully');
    }
  } catch (error) {
    console.error('Error handling button click action:', error);
  }
});

// Express route for external service
expressApp.post('/notify', (req, res) => {
  const { userId, event } = req.body;
  console.log(`Received notification: User ${userId} triggered event ${event}`); // Debugging: Track notification received
  
  res.status(200).send('Notification received');
});

// Start both Slack Bolt app and Express server
(async () => {
  try {
    await slackApp.start(process.env.PORT || 3000);
    console.log('⚡️ Bolt app started on Slack');
  } catch (error) {
    console.error('Error starting Slack app:', error);
  }
  
  const expressPort = 4000;
  expressApp.listen(expressPort, () => {
    console.log(`🌐 Express app started on http://localhost:${expressPort}`);
  });
})();
