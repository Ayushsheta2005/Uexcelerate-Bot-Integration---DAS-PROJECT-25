require('dotenv').config();
const express = require('express');
const { App } = require('@slack/bolt');

// Initialize the Slack App (Bolt)
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
});

// Sample data
const coaches = [
  { id: 1, name: 'Alice', expertise: 'Leadership', availability: 'Weekdays', rating: 4.5 },
  { id: 2, name: 'Bob', expertise: 'Career Growth', availability: 'Weekends', rating: 4.7 },
];

// Function to search coaches
const searchCoaches = () => {
  return coaches
    .map(
      (coach) =>
        `👤 ${coach.name} | Expertise: ${coach.expertise} | Availability: ${coach.availability} | Rating: ${coach.rating}`
    )
    .join('\n');
};

// Slack message handlers
slackApp.message(/search coach/i, async ({ say }) => {
  await say(searchCoaches());
});

slackApp.message(/help/i, async ({ say }) => {
  await say(`Here are the commands you can use:
- "search coach": View all available coaches.`);
});

// Start the Slack App
(async () => {
  try {
    const slackPort = process.env.SLACK_PORT || 3001;
    await slackApp.start(slackPort);
    console.log(`⚡️ Slack app is running on port ${slackPort}`);
  } catch (error) {
    console.error('Error starting Slack app:', error);
  }
})();

// Express app for additional routes or health checks
const app = express();
const port = process.env.PORT || 3000;

// Add a health check route
app.get('/', (req, res) => res.send('Bot is running! 🚀'));

// Redirect `/slack/events` to Bolt
app.use('/slack/events', slackApp.receiver.app);

// Start the Express server
app.listen(port, () => {
  console.log(`🌐 Express server is running on port ${port}`);
});
