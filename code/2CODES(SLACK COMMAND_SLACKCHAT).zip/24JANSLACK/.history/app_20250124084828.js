const { App } = require('@slack/bolt');
require('dotenv').config();

// Initialize Slack app
const app = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET
});

// Slash Command handler
app.command('/mycommand', async ({ ack, respond }) => {
  // Acknowledge the slash command request
  await ack();

  // Send a response to the user
  await respond({
    text: 'Hello, this is your command response!',
  });
});

// Start your app
(async () => {
  try {
    await app.start(process.env.PORT || 3000);
    console.log('⚡️ Bolt app started');
  } catch (error) {
    console.error('Error starting app:', error);
  }
})();
