slackApp.command('/survey', async ({ ack, body, respond }) => {
  await ack();  // Acknowledge the slash command
  
  // Ask for text input
  await respond({
    text: 'Please enter your response below:',
    response_type: 'ephemeral',  // Only visible to the user who triggered it
  });

  // Handle incoming user text after command is invoked
  slackApp.message('response', async ({ message, say }) => {
    if (message.text) {
      // Process the user's input
      await say(`Received your input: "${message.text}"`);
    }
  });
});
