// src/index.js

const { App } = require('@slack/bolt');
const express = require('express');
const bodyParser = require('body-parser');
require('dotenv').config();

// Initialize Bolt App (for handling events and commands)
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
  socketMode: true,
  appToken: process.env.SLACK_APP_TOKEN,
});

// Initialize Express (for handling Slash Commands, Interactions, etc.)
const expressApp = express();
expressApp.use(bodyParser.json());

// Sample Slash Command endpoint
expressApp.post('/slack/commands', async (req, res) => {
  const { command, text } = req.body;
  if (command === '/hello') {
    res.send(`Hello! 👋 You said: "${text}"`);
  } else if (command === '/weather') {
    const location = text || 'your location';
    res.send(`🌤️ Weather for ${location}:
    - Temperature: 72°F
    - Condition: Sunny
    - Humidity: 45%`);
  } else {
    res.send("Unknown command!");
  }
});

// Interactive Components endpoint
expressApp.post('/slack/interactions', async (req, res) => {
  const payload = JSON.parse(req.body.payload); // Interactive payload from Slack
  if (payload.type === 'block_actions') {
    const action = payload.actions[0];
    if (action.action_id === 'lunch_selection') {
      const selection = action.value;
      res.send(`Enjoy your ${selection}! 🍽️`);
    }
  }
});

// Start the Slack Bolt App
(async () => {
  try {
    await slackApp.start(process.env.PORT || 3000);
    console.log('⚡️ Bolt app is running!');
  } catch (error) {
    console.error('Error starting app', error);
  }
})();

// Start the Express server
expressApp.listen(process.env.PORT || 3000, () => {
  console.log(`Express server listening on port ${process.env.PORT || 3000}`);
});
