require('dotenv').config();
const { App } = require('@slack/bolt');
const express = require('express');

// Initialize Slack App with bot token and signing secret
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
});

// Initialize Express app
const app = express();

// Middleware to parse incoming JSON requests
app.use(express.json());

// Sample mock data for coaches, goals, and sessions
const coaches = [
  { id: 1, name: 'Alice', expertise: 'Leadership' },
  { id: 2, name: 'Bob', expertise: 'Career Growth' },
  { id: 3, name: 'Charlie', expertise: 'Motivation' },
];

let goals = [];
let actions = [];
let sessions = [];

// Function to create and display available coaches
const displayCoaches = () => {
  return {
    blocks: [
      {
        type: 'section',
        block_id: 'coaches_list',
        text: {
          type: 'mrkdwn',
          text: '*Available Coaches*:\nPlease select a coach to schedule a session:',
        },
      },
      {
        type: 'actions',
        elements: coaches.map(coach => ({
          type: 'button',
          text: {
            type: 'plain_text',
            text: coach.name,
          },
          value: coach.name,  // Use the coach's name as the value
          action_id: 'select_coach',  // This is the unique action ID
        })),
      },
    ],
  };
};

// Function to show all goals
const showGoals = () => {
  return {
    blocks: [
      {
        type: 'section',
        block_id: 'goals_list',
        text: {
          type: 'mrkdwn',
          text: '*Your Goals*:\nHere are the goals you have set:',
        },
      },
      ...goals.map(goal => ({
        type: 'section',
        fields: [
          { type: 'mrkdwn', text: `*Goal:* ${goal.description}` },
          { type: 'mrkdwn', text: `*Status:* ${goal.status}` },
        ],
      })),
      {
        type: 'divider',
      },
    ],
  };
};

// Function to show all actions
const showActions = () => {
  return {
    blocks: [
      {
        type: 'section',
        block_id: 'actions_list',
        text: {
          type: 'mrkdwn',
          text: '*Your Actions*:\nHere are the actions you have created:',
        },
      },
      ...actions.map(action => ({
        type: 'section',
        fields: [
          { type: 'mrkdwn', text: `*Action:* ${action.description}` },
          { type: 'mrkdwn', text: `*Assigned Coach:* ${action.coach}` },
        ],
      })),
      {
        type: 'divider',
      },
    ],
  };
};

// Function to handle scheduling a session
const scheduleSession = (userId, coachName) => {
  const session = {
    id: sessions.length + 1,
    coach: coachName,
    date: '2025-02-01',  // Hardcoded date for simplicity
    user: userId,
  };
  sessions.push(session);

  return {
    blocks: [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*Session Scheduled Successfully* 📅\nCoach: *${coachName}*\nDate: *2025-02-01*`,
        },
      },
      {
        type: 'divider',
      },
    ],
  };
};

// Function to create a goal
const createGoal = (description) => {
  const goal = {
    id: goals.length + 1,
    description,
    status: 'Not Started', // Default status
  };
  goals.push(goal);
};

// Function to create an action
const createAction = (description, coach) => {
  const action = {
    id: actions.length + 1,
    description,
    coach,
  };
  actions.push(action);
};

// Slack Bot Handlers
slackApp.message(/create goal/i, async ({ message, say }) => {
  if (message.user !== process.env.SLACK_BOT_USER_ID && !message.subtype) {
    await say({
      text: 'Please provide a description for your goal.',
      // Optional: You can add an input field or modal for a better experience
    });
  }
});

slackApp.message(/create action/i, async ({ message, say }) => {
  if (message.user !== process.env.SLACK_BOT_USER_ID && !message.subtype) {
    await say({
      text: 'Please provide a description for your action.',
      // Optional: You can add an input field or modal for a better experience
    });
  }
});

// Handle user requests for available coaches and session scheduling
slackApp.message(/schedule session/i, async ({ message, say }) => {
  if (message.user !== process.env.SLACK_BOT_USER_ID && !message.subtype) {
    // Display available coaches when user requests to schedule a session
    await say(displayCoaches());
  }
});

// Handle button click actions (when a coach is selected)
slackApp.action('select_coach', async ({ body, ack, say }) => {
  await ack(); // Acknowledge the interaction

  const selectedCoach = body.actions[0].value;  // Get the selected coach name
  const userId = body.user.id;  // Get the user ID of the person who clicked the button

  // Schedule a session with the selected coach
  const sessionMessage = scheduleSession(userId, selectedCoach);

  // Respond with the session confirmation message
  await say(sessionMessage);
});

// Handle goal creation action
slackApp.action('create_goal', async ({ body, ack, say }) => {
  await ack();
  const goalDescription = body.actions[0].value;
  createGoal(goalDescription);
  
  await say({
    text: `Your goal: *${goalDescription}* has been created successfully!`,
  });
});

// Handle action creation action
slackApp.action('create_action', async ({ body, ack, say }) => {
  await ack();
  const { description, coach } = body.actions[0].value;
  createAction(description, coach);
  
  await say({
    text: `Your action: *${description}* has been created with coach *${coach}*!`,
  });
});

// Show goals when user asks
slackApp.message(/show goals/i, async ({ message, say }) => {
  if (message.user !== process.env.SLACK_BOT_USER_ID && !message.subtype) {
    await say(showGoals());
  }
});

// Show actions when user asks
slackApp.message(/show actions/i, async ({ message, say }) => {
  if (message.user !== process.env.SLACK_BOT_USER_ID && !message.subtype) {
    await say(showActions());
  }
});

// Add the route to handle Slack events (like button interactions)
app.post('/slack/actions', async (req, res) => {
  try {
    const { type, challenge, event } = req.body;
    
    // Respond to Slack URL verification challenge
    if (type === 'url_verification') {
      return res.json({ challenge });
    }

    if (event && event.type === 'message' && event.text) {
      const text = event.text.toLowerCase();
      
      if (text.includes('schedule session')) {
        // If the user asks to schedule a session, send the list of coaches
        await slackApp.client.chat.postMessage({
          channel: event.channel,
          blocks: displayCoaches().blocks,
        });
      }

      if (text.includes('show goals')) {
        // Show all goals when user asks
        await slackApp.client.chat.postMessage({
          channel: event.channel,
          blocks: showGoals().blocks,
        });
      }

      if (text.includes('show actions')) {
        // Show all actions when user asks
        await slackApp.client.chat.postMessage({
          channel: event.channel,
          blocks: showActions().blocks,
        });
      }
    }

    res.status(200).send();
  } catch (error) {
    console.error('Error handling Slack event:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Start the Slack app
(async () => {
  try {
    const slackPort = process.env.SLACK_PORT || 3001;
    await slackApp.start(slackPort);
    console.log(`⚡️ Slack app is running on port ${slackPort}`);
  } catch (error) {
    console.error('Error starting Slack app:', error);
  }
})();

// Start the Express server
const port = process.env.PORT || 3000;
app.get('/', (req, res) => res.send('Bot is running! 🚀'));
app.listen(port, () => {
  console.log(`🌐 Server is running on port ${port}`);
});
