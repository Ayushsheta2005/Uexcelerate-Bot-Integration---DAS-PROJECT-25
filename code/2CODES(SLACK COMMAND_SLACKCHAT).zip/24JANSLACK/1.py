import os
from slack_bolt import App
from slack_bolt.adapter.socket_mode import SocketModeHandler

# Load environment variables from .env file
from dotenv import load_dotenv
load_dotenv()

# Initialize your app with your bot token and signing secret
slack_app = App(
    token=os.getenv('SLACK_BOT_TOKEN'),
    signing_secret=os.getenv('SLACK_SIGNING_SECRET')
)

# Listens to incoming messages that contain "hello"
@slack_app.message("hello")
def say_hello(message, say):
    say(
        text="Click the button!",
        blocks=[
            {
                "type": "actions",
                "elements": [
                    {
                        "type": "button",
                        "text": {"type": "plain_text", "text": "Click Me"},
                        "action_id": "sample_button",
                        "value": "button_clicked"
                    }
                ]
            }
        ]
    )

# Handles the button click action
@slack_app.action("sample_button")
def handle_button_click(body, ack, say):
    ack()
    user_id = body["user"]["id"]
    say(f"Button was clicked by <@{user_id}>!")

# Start the app
if __name__ == "__main__":
    # Use SocketModeHandler to run the app with the app-level token
    handler = SocketModeHandler(slack_app, os.getenv("SLACK_APP_TOKEN"))
    handler.start()
