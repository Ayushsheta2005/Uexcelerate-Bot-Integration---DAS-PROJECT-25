const express = require("express");
const bodyParser = require("body-parser");
const crypto = require("crypto");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;

// Hardcoded sample data
const coaches = [
  { name: "Alice", subject: "math" },
  { name: "Bob", subject: "science" },
  { name: "Charlie", subject: "english" },
];

// Middleware to parse incoming requests
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Serve static files from the public folder
app.use(express.static("public"));

// Middleware to check if .env is loaded
if (!process.env.PORT) {
  console.error("⚠️  Missing .env file or PORT variable!");
  process.exit(1);
}

// Route: API endpoint to fetch coaches
app.get("/api/coaches", (req, res) => {
  const { subject } = req.query;

  if (subject) {
    const filteredCoaches = coaches.filter((coach) =>
      coach.subject.toLowerCase().includes(subject.toLowerCase())
    );
    return res.json(filteredCoaches);
  }

  res.json(coaches);
});

// Route: Handle Slack commands
app.post("/slack/commands", (req, res) => {
  const { command, text } = req.body;

  if (!command || command !== "/coach") {
    return res.status(400).send("Unknown command or missing command.");
  }

  const subject = text ? text.trim().toLowerCase() : "";

  // Filter coaches based on subject
  const filteredCoaches = subject
    ? coaches.filter((coach) =>
        coach.subject.toLowerCase().includes(subject)
      )
    : coaches;

  if (filteredCoaches.length > 0) {
    const responseText = filteredCoaches
      .map((coach) => `• ${coach.name} (${coach.subject})`)
      .join("\n");

    return res.json({
      response_type: "in_channel",
      text: `Here are the coaches:\n${responseText}`,
    });
  } else {
    return res.json({
      response_type: "ephemeral",
      text: subject
        ? `No coaches found for subject: ${subject}`
        : "No coaches found.",
    });
  }
});

// Global Error Handling Middleware
app.use((err, req, res, next) => {
  console.error("An error occurred:", err.message);
  res.status(500).json({ error: "Internal Server Error" });
});

// Start the server
app.listen(PORT, () => {
  console.log(`✅ Server is running at http://localhost:${PORT}`);
});
