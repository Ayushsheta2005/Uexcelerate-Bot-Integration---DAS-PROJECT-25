const express = require("express");
const bodyParser = require("body-parser");
const crypto = require("crypto");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;

// Hardcoded sample data
const coaches = [
  { name: "Alice", subject: "math" },
  { name: "Bob", subject: "science" },
  { name: "Charlie", subject: "english" },
];

// Middleware to parse incoming requests
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Serve static files from the public folder
app.use(express.static("public"));

// Route: API endpoint to fetch coaches
app.get("/api/coaches", (req, res) => {
  const { subject } = req.query;

  if (subject) {
    const filteredCoaches = coacconst express = require("express");
const bodyParser = require("body-parser");
const crypto = require("crypto");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;

// Hardcoded sample data
const coaches = [
  { name: "Alice", subject: "math" },
  { name: "Bob", subject: "science" },
  { name: "Charlie", subject: "english" },
];

// Middleware to parse incoming requests
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Serve static files from the public folder
app.use(express.static("public"));

// Route: API endpoint to fetch coaches
app.get("/api/coaches", (req, res) => {
  const { subject } = req.query;

  if (subject) {
    const filteredCoaches = coaches.filter((coach) =>
      coach.subject.toLowerCase().includes(subject.toLowerCase())
    );
    return res.json(filteredCoaches);
  }

  res.json(coaches);
});

// Route: Handle Slack commands
app.post("/slack/commands", (req, res) => {
  const { command, text } = req.body;

  if (command === "/coach") {
    const subject = text.trim().toLowerCase();

    // Filter coaches based on subject
    const filteredCoaches = subject
      ? coaches.filter((coach) =>
          coach.subject.toLowerCase().includes(subject)
        )
      : coaches;

    if (filteredCoaches.length > 0) {
      const responseText = filteredCoaches
        .map((coach) => `• ${coach.name} (${coach.subject})`)
        .join("\n");

      return res.json({
        response_type: "in_channel",
        text: `Here are the coaches:\n${responseText}`,
      });
    } else {
      return res.json({
        response_type: "ephemeral",
        text: `No coaches found for subject: ${subject}`,
      });
    }
  } else {
    res.status(400).send("Unknown command.");
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
hes.filter((coach) =>
      coach.subject.toLowerCase().includes(subject.toLowerCase())
    );
    return res.json(filteredCoaches);
  }

  res.json(coaches);
});

// Route: Handle Slack commands
app.post("/slack/commands", (req, res) => {
  const { command, text } = req.body;

  if (command === "/coach") {
    const subject = text.trim().toLowerCase();

    // Filter coaches based on subject
    const filteredCoaches = subject
      ? coaches.filter((coach) =>
          coach.subject.toLowerCase().includes(subject)
        )
      : coaches;

    if (filteredCoaches.length > 0) {
      const responseText = filteredCoaches
        .map((coach) => `• ${coach.name} (${coach.subject})`)
        .join("\n");

      return res.json({
        response_type: "in_channel",
        text: `Here are the coaches:\n${responseText}`,
      });
    } else {
      return res.json({
        response_type: "ephemeral",
        text: `No coaches found for subject: ${subject}`,
      });
    }
  } else {
    res.status(400).send("Unknown command.");
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
