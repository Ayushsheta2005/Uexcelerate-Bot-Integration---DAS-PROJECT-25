const express = require("express");
const bodyParser = require("body-parser");
const crypto = require("crypto");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;

const coaches = [
  {
    id: 1,
    name: "Alice",
    subject: "math",
    specialties: ["algebra", "calculus"],
  },
  {
    id: 2,
    name: "Bob",
    subject: "science",
    specialties: ["physics", "chemistry"],
  },
  {
    id: 3,
    name: "Charlie",
    subject: "english",
    specialties: ["grammar", "literature"],
  },
];

const goals = [];
const sessions = [];

// Middleware to parse incoming requests
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static("public"));

if (!process.env.PORT) {
  console.error("⚠️  Missing .env file or PORT variable!");
  process.exit(1);
}

// Helper function to create block kit messages
const createCoachBlockMessage = (coaches) => {
  return coaches.map(coach => ({
    type: "section",
    text: {
      type: "mrkdwn",
      text: `*${coach.name}* - *${coach.subject}*\nSpecialties: ${coach.specialties.join(", ")}`,
    },
  }));
};

const createGoalBlockMessage = (goal, description) => {
  return {
    type: "section",
    text: {
      type: "mrkdwn",
      text: `*Goal*: ${goal}\n*Description*: ${description}`,
    },
  };
};

const createSessionBlockMessage = (session) => {
  return {
    type: "section",
    text: {
      type: "mrkdwn",
      text: `*Session with ${session.coach}* on *${session.date}* at *${session.time}*`,
    },
    accessory: {
      type: "button",
      text: {
        type: "plain_text",
        text: "Cancel Session",
      },
      action_id: `cancel_session_${session.id}`,
    },
  };
};

// Route: Fetch coaches
app.get("/api/coaches", (req, res) => {
  const { subject, specialty } = req.query;
  let filteredCoaches = coaches;

  if (subject) {
    filteredCoaches = filteredCoaches.filter((coach) =>
      coach.subject.toLowerCase().includes(subject.toLowerCase())
    );
  }

  if (specialty) {
    filteredCoaches = filteredCoaches.filter((coach) =>
      coach.specialties.some((spec) =>
        spec.toLowerCase().includes(specialty.toLowerCase())
      )
    );
  }

  res.json(filteredCoaches);
});

// Slack commands handler
app.post("/slack/commands", (req, res) => {
  const { command, text, user_id } = req.body;

  if (!command) {
    return res.status(400).send("Missing command.");
  }

  switch (command) {
    case "/coach": {
      const subject = text ? text.trim().toLowerCase() : "";

      const filteredCoaches = subject
        ? coaches.filter((coach) =>
            coach.subject.toLowerCase().includes(subject)
          )
        : coaches;

      if (filteredCoaches.length > 0) {
        return res.json({
          response_type: "in_channel",
          blocks: createCoachBlockMessage(filteredCoaches),
        });
      } else {
        return res.json({
          response_type: "ephemeral",
          text: subject
            ? `❗ No coaches found for subject: ${subject}`
            : "❗ No coaches found.",
        });
      }
    }

    case "/addgoal": {
      const [goal, description] = text.split(",").map((item) => item.trim());

      if (!goal || !description) {
        return res.json({
          response_type: "ephemeral",
          text: "❗ Please provide both goal and description. Example: `/addgoal Goal, Description`",
        });
      }

      const id = crypto.randomUUID();
      goals.push({ id, goal, description, user_id });

      return res.json({
        response_type: "ephemeral",
        blocks: [createGoalBlockMessage(goal, description)],
        text: `✅ Goal added successfully.`,
      });
    }

    case "/addsession": {
      const [coachName, date, time] = text.split(",").map((item) => item.trim());

      if (!coachName || !date || !time) {
        return res.json({
          response_type: "ephemeral",
          text: "❗ Please provide coach name, date, and time. Example: `/addsession CoachName, YYYY-MM-DD, HH:MM`",
        });
      }

      const coach = coaches.find(
        (c) => c.name.toLowerCase() === coachName.toLowerCase()
      );

      if (!coach) {
        return res.json({
          response_type: "ephemeral",
          text: `❗ Coach not found: ${coachName}`,
        });
      }

      const sessionId = crypto.randomUUID();
      sessions.push({ id: sessionId, coach: coach.name, date, time, user_id });

      return res.json({
        response_type: "ephemeral",
        blocks: [createSessionBlockMessage({ coach: coach.name, date, time, id: sessionId })],
        text: `✅ Session added with ${coach.name} on ${date} at ${time}.`,
      });
    }

    case "/listsessions": {
      const userSessions = sessions.filter((session) => session.user_id === user_id);

      if (userSessions.length === 0) {
        return res.json({
          response_type: "ephemeral",
          text: "❗ You don't have any upcoming sessions.",
        });
      }

      const blocks = userSessions.map((session) => createSessionBlockMessage(session));

      return res.json({
        response_type: "ephemeral",
        blocks,
        text: "Here are your upcoming sessions:",
      });
    }

    case "/deletegoal": {
      const goalId = text.trim();

      const index = goals.findIndex((goal) => goal.id === goalId && goal.user_id === user_id);
      if (index === -1) {
        return res.json({
          response_type: "ephemeral",
          text: `❗ Goal not found or you don't have permission to delete it.`,
        });
      }

      goals.splice(index, 1);

      return res.json({
        response_type: "ephemeral",
        text: `✅ Goal deleted successfully.`,
      });
    }

    default:
      return res.json({
        response_type: "ephemeral",
        text: "❗ Unknown command. Available commands: `/coach`, `/addgoal`, `/addsession`, `/listsessions`, `/deletegoal`.",
      });
  }
});

// Global Error Handling Middleware
app.use((err, req, res, next) => {
  console.error("An error occurred:", err.message);
  res.status(500).json({ error: "Internal Server Error" });
});

// Start the server
app.listen(PORT, () => {
  console.log(`✅ Server is running at http://localhost:${PORT}`);
});
/