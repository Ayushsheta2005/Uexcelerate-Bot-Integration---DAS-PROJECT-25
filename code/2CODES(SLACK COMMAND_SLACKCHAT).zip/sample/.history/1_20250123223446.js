const express = require("express");
const bodyParser = require("body-parser");
const { App } = require("@slack/bolt");
const mongoose = require("mongoose");
require("dotenv").config();

// MongoDB Models
const Coach = require("./models/Coach");
const Session = require("./models/Session");
const User = require("./models/User");

// Initialize Express and Slack App
const app = express();
const slackApp = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET,
});

const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// MongoDB Connection
mongoose
  .connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("MongoDB connection error:", err));

// Slash Commands
slackApp.command("/add-coach", async ({ command, ack, respond }) => {
  await ack();
  const [name, subject, skillLevel, pricing] = command.text.split(" ");
  if (!name || !subject || !skillLevel || !pricing) {
    return respond("Usage: /add-coach [name] [subject] [skill_level] [pricing]");
  }
  const coach = new Coach({ name, subject, skillLevel, pricing });
  await coach.save();
  respond(`Coach *${name}* added successfully.`);
});

slackApp.command("/list-coaches", async ({ command, ack, respond }) => {
  await ack();
  const [subject, skillLevel] = command.text.split(" ");
  let query = {};
  if (subject) query.subject = new RegExp(subject, "i");
  if (skillLevel) query.skillLevel = new RegExp(skillLevel, "i");
  const coaches = await Coach.find(query);
  if (coaches.length === 0) return respond("No coaches available.");
  const blocks = coaches.map((coach) => ({
    type: "section",
    text: {
      type: "mrkdwn",
      text: `*${coach.name}*\n*Subject:* ${coach.subject}\n*Skill Level:* ${coach.skillLevel}\n*Price:* $${coach.pricing}/hr`,
    },
    accessory: {
      type: "button",
      text: { type: "plain_text", text: "Book" },
      value: coach._id.toString(),
      action_id: `book_${coach._id}`,
    },
  }));
  respond({ text: "Here are the available coaches:", blocks });
});

slackApp.command("/cancel-session", async ({ command, ack, respond }) => {
  await ack();
  const sessionId = command.text.trim();
  const session = await Session.findById(sessionId);
  if (!session) return respond("Session not found.");
  session.status = "cancelled";
  await session.save();
  respond(`Session with ID ${sessionId} has been cancelled.`);
});

slackApp.command("/feedback", async ({ command, ack, respond }) => {
  await ack();
  const [coachId, rating, ...commentParts] = command.text.split(" ");
  const comment = commentParts.join(" ");
  const coach = await Coach.findById(coachId);
  if (!coach || !rating || !comment) {
    return respond("Usage: /feedback [coach_id] [rating] [comment]");
  }
  coach.reviews.push({ rating, comment });
  await coach.save();
  respond(`Feedback submitted for Coach ${coach.name}.`);
});

// Interactive Actions
slackApp.action(/book_/, async ({ action, ack, body, respond }) => {
  await ack();
  const coachId = action.value;
  const coach = await Coach.findById(coachId);
  if (!coach) return respond("Coach not found.");
  await slackApp.client.views.open({
    trigger_id: body.trigger_id,
    view: {
      type: "modal",
      callback_id: "book_session_modal",
      private_metadata: coachId,
      title: { type: "plain_text", text: "Book a Session" },
      blocks: [
        {
          type: "input",
          block_id: "date_block",
          element: {
            type: "plain_text_input",
            action_id: "date_input",
            placeholder: { type: "plain_text", text: "Enter the date (e.g., 2025-01-20)" },
          },
          label: { type: "plain_text", text: "Session Date" },
        },
        {
          type: "input",
          block_id: "time_block",
          element: {
            type: "plain_text_input",
            action_id: "time_input",
            placeholder: { type: "plain_text", text: "Enter the time (e.g., 14:00)" },
          },
          label: { type: "plain_text", text: "Session Time" },
        },
      ],
      submit: { type: "plain_text", text: "Book" },
    },
  });
});

// Modal Submission
slackApp.view("book_session_modal", async ({ ack, body, view }) => {
  await ack();
  const coachId = view.private_metadata;
  const date = view.state.values.date_block.date_input.value;
  const time = view.state.values.time_block.time_input.value;
  const userId = body.user.id;
  const session = new Session({ userId, coachId, date: `${date} ${time}`, status: "upcoming" });
  await session.save();
  slackApp.client.chat.postMessage({
    channel: userId,
    text: `Your session with Coach ${coachId} has been booked for ${date} at ${time}.`,
  });
});

// Start Server
(async () => {
  await slackApp.start(PORT);
  console.log(`⚡️ Slack app is running on port ${PORT}`);
})();
