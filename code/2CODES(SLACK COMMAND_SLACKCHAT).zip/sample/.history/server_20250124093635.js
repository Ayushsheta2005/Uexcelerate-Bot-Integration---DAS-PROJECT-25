// Route: Handle Slack commands
app.post("/slack/commands", (req, res) => {
    const { command, text } = req.body;
  
    console.log("Command received:", command); // Debugging
    console.log("Text received:", text); // Debugging
  
    if (!command) {
      return res.status(400).send("Missing command.");
    }
  
    switch (command) {
      case "/addgoal": {
        const [goal, description] = text.split(",").map((item) => item.trim());
  
        console.log("Goal:", goal); // Debugging
        console.log("Description:", description); // Debugging
  
        if (!goal || !description) {
          return res.status(400).json({
            response_type: "ephemeral",
            text: "Please provide both goal and description. Example: /addgoal Goal, Description",
          });
        }
  
        const id = crypto.randomUUID();
        goals.push({ id, goal, description });
  
        console.log("Goal added:", { id, goal, description }); // Debugging
  
        return res.json({
          response_type: "ephemeral", // Ensure it's valid for Slack response
          text: `Goal added successfully: ${goal} - ${description}`,
        });
      }
  
      default:
        return res.status(400).json({
          response_type: "ephemeral",
          text: "Unknown command. Available commands: /coach, /addgoal, /addsession",
        });
    }
  });
  